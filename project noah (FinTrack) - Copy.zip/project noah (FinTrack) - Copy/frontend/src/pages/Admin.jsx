import { useState } from "react";
import { api } from "../api";
import { useApi } from "../hooks";
import { dateFull } from "../format";
import { useAuth } from "../store.jsx";
import { Btn, Empty, ErrorMsg, Field, Input, Loading, Notice, Page, Section, Select, Stats, Table, Td, Th } from "../ui.jsx";

export default function Admin() {
  const { user } = useAuth();
  const isAdmin = user.role === "admin";
  const stats = useApi(() => api("/api/admin/stats"));
  const cats = useApi(() => api("/api/categories"));
  const secs = useApi(() => api("/api/securities"));
  const classes = useApi(() => api("/api/asset-classes"));
  const users = useApi(() => (isAdmin ? api("/api/users") : Promise.resolve([])), [isAdmin]);
  const audit = useApi(() => (isAdmin ? api("/api/admin/audit-log?limit=15") : Promise.resolve([])), [isAdmin]);

  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);
  const [cat, setCat] = useState({ name: "", kind: "expense" });
  const [sec, setSec] = useState({ symbol: "", name: "", asset_class_id: "" });
  const [price, setPrice] = useState({ security_id: "", price_date: new Date().toISOString().slice(0, 10), close_price: "" });
  const [nu, setNu] = useState({ full_name: "", email: "", password: "", role: "staff" });

  const run = async (fn, msg, reloaders = []) => {
    setError(null); setNotice(null);
    try { await fn(); if (msg) setNotice(msg); reloaders.forEach((r) => r.reload()); } catch (e) { setError(e.message); }
  };
  const system = (cats.data ?? []).filter((c) => c.is_system);
  const s = stats.data;

  return (
    <Page title={isAdmin ? "Admin" : "Staff"}
          subtitle="Shared reference data and platform health. Staff can see usage counts but never a customer's transactions.">
      <ErrorMsg error={error} />
      {notice && <Notice tone="good">{notice}</Notice>}

      <Section title="Platform">
        {!s ? <Loading /> : (
          <div className="space-y-3">
            <Stats items={[
              { label: "Users", value: s.users }, { label: "Customers", value: s.customers },
              { label: "Accounts", value: s.accounts }, { label: "Transactions", value: s.transactions }]} />
            <Stats items={[
              { label: "Categorised by AI", value: s.ai_categorized }, { label: "Categorised by rules", value: s.rule_categorized },
              { label: "Awaiting review", value: s.uncategorized }, { label: "AI insights written", value: s.insights_generated }]} />
          </div>
        )}
      </Section>

      <Section title="System categories" hint="visible to every customer">
        <div className="mb-4 flex flex-wrap gap-2">
          {system.map((c) => (
            <span key={c.id} className="inline-flex items-center gap-1.5 rounded-full border border-line bg-surface px-3 py-1 text-sm">
              {c.name} <span className="text-xs text-muted">{c.kind}</span>
              <button className="text-muted hover:text-outflow" aria-label={`Delete ${c.name}`}
                      onClick={() => confirm(`Delete “${c.name}”?`) && run(() => api(`/api/categories/${c.id}`, { method: "DELETE" }), "Category deleted.", [cats])}>×</button>
            </span>
          ))}
        </div>
        <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => { e.preventDefault();
          run(async () => { await api("/api/categories", { method: "POST", body: { ...cat, is_system: true } }); setCat({ ...cat, name: "" }); }, "Category added.", [cats]); }}>
          <Field label="Name"><Input required maxLength={60} value={cat.name} onChange={(e) => setCat({ ...cat, name: e.target.value })} /></Field>
          <Field label="Kind"><Select value={cat.kind} onChange={(e) => setCat({ ...cat, kind: e.target.value })}>
            <option value="expense">Expense</option><option value="income">Income</option><option value="transfer">Transfer</option></Select></Field>
          <Btn type="submit">Add category</Btn>
        </form>
      </Section>

      <Section title="Securities & prices">
        {(secs.data ?? []).length === 0 ? <Empty>No securities yet.</Empty> : (
          <Table>
            <thead><tr><Th>Symbol</Th><Th>Name</Th><Th>Class</Th><Th /></tr></thead>
            <tbody>{secs.data.map((x) => (
              <tr key={x.id}><Td className="font-semibold">{x.symbol}</Td><Td>{x.name}</Td>
                <Td>{classes.data?.find((c) => c.id === x.asset_class_id)?.name}</Td>
                <Td><button className="text-xs text-muted hover:text-outflow"
                  onClick={() => confirm(`Delete ${x.symbol}?`) && run(() => api(`/api/securities/${x.id}`, { method: "DELETE" }), "Security deleted.", [secs])}>Delete</button></Td></tr>))}
            </tbody>
          </Table>
        )}
        <div className="mt-4 grid gap-6 md:grid-cols-2">
          <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => { e.preventDefault();
            run(async () => { await api("/api/securities", { method: "POST", body: {
              ...sec, asset_class_id: Number(sec.asset_class_id || classes.data[0].id) } }); setSec({ symbol: "", name: "", asset_class_id: "" }); }, "Security added.", [secs]); }}>
            <Field label="Symbol"><Input required maxLength={12} className="w-24" value={sec.symbol} onChange={(e) => setSec({ ...sec, symbol: e.target.value })} /></Field>
            <Field label="Name"><Input required maxLength={100} value={sec.name} onChange={(e) => setSec({ ...sec, name: e.target.value })} /></Field>
            <Field label="Class"><Select value={sec.asset_class_id || classes.data?.[0]?.id || ""} onChange={(e) => setSec({ ...sec, asset_class_id: e.target.value })}>
              {(classes.data ?? []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></Field>
            <Btn type="submit">Add security</Btn>
          </form>
          <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => { e.preventDefault();
            run(async () => { await api(`/api/securities/${price.security_id || secs.data[0].id}/prices`, { method: "POST",
              body: { price_date: price.price_date, close_price: Number(price.close_price) } }); setPrice({ ...price, close_price: "" }); }, "Price saved.");}}>
            <Field label="Security"><Select value={price.security_id || secs.data?.[0]?.id || ""} onChange={(e) => setPrice({ ...price, security_id: e.target.value })}>
              {(secs.data ?? []).map((x) => <option key={x.id} value={x.id}>{x.symbol}</option>)}</Select></Field>
            <Field label="Date"><Input required type="date" value={price.price_date} onChange={(e) => setPrice({ ...price, price_date: e.target.value })} /></Field>
            <Field label="Close price"><Input required type="number" min="0.0001" step="any" className="w-28" value={price.close_price} onChange={(e) => setPrice({ ...price, close_price: e.target.value })} /></Field>
            <Btn type="submit" disabled={!secs.data?.length}>Save price</Btn>
          </form>
        </div>
      </Section>

      {isAdmin && (
        <>
          <Section title="Users">
            {users.loading && !users.data ? <Loading /> : (
              <Table>
                <thead><tr><Th>Name</Th><Th>Email</Th><Th>Role</Th><Th>Status</Th><Th /></tr></thead>
                <tbody>{(users.data ?? []).map((u) => (
                  <tr key={u.id} className={u.is_active ? "" : "opacity-50"}>
                    <Td className="font-semibold">{u.full_name}</Td><Td>{u.email}</Td>
                    <Td><Select className="py-1" value={u.role} disabled={u.id === user.id} aria-label={`Role for ${u.full_name}`}
                      onChange={(e) => run(() => api(`/api/users/${u.id}`, { method: "PUT", body: { role: e.target.value } }), "Role updated.", [users, audit])}>
                      <option value="customer">customer</option><option value="staff">staff</option><option value="admin">admin</option></Select></Td>
                    <Td>{u.is_active ? "Active" : "Disabled"}</Td>
                    <Td className="space-x-3 whitespace-nowrap text-right">
                      {u.id !== user.id && <>
                        <button className="text-xs text-muted hover:text-brand"
                          onClick={() => run(() => api(`/api/users/${u.id}`, { method: "PUT", body: { is_active: !u.is_active } }), u.is_active ? "User disabled." : "User enabled.", [users, audit])}>
                          {u.is_active ? "Disable" : "Enable"}</button>
                        <button className="text-xs text-muted hover:text-outflow"
                          onClick={() => confirm(`Permanently delete ${u.email} and ALL their data?`) && run(() => api(`/api/users/${u.id}`, { method: "DELETE" }), "User deleted.", [users])}>
                          Delete</button></>}
                    </Td>
                  </tr>))}
                </tbody>
              </Table>
            )}
            <form className="mt-4 flex flex-wrap items-end gap-3" onSubmit={(e) => { e.preventDefault();
              run(async () => { await api("/api/users", { method: "POST", body: nu }); setNu({ ...nu, full_name: "", email: "", password: "" }); }, "User created.", [users]); }}>
              <Field label="Full name"><Input required value={nu.full_name} onChange={(e) => setNu({ ...nu, full_name: e.target.value })} /></Field>
              <Field label="Email"><Input required type="email" value={nu.email} onChange={(e) => setNu({ ...nu, email: e.target.value })} /></Field>
              <Field label="Password"><Input required type="password" minLength={8} maxLength={72} autoComplete="new-password" value={nu.password} onChange={(e) => setNu({ ...nu, password: e.target.value })} /></Field>
              <Field label="Role"><Select value={nu.role} onChange={(e) => setNu({ ...nu, role: e.target.value })}>
                <option value="staff">staff</option><option value="admin">admin</option><option value="customer">customer</option></Select></Field>
              <Btn type="submit">Create user</Btn>
            </form>
          </Section>

          <Section title="Audit log" hint="role and activation changes, written by a database trigger">
            {(audit.data ?? []).length === 0 ? <Empty>No changes recorded yet. Change a user's role to see an entry.</Empty> : (
              <Table>
                <thead><tr><Th>When</Th><Th>User id</Th><Th>Before</Th><Th>After</Th></tr></thead>
                <tbody>{audit.data.map((a) => (
                  <tr key={a.id}><Td className="whitespace-nowrap">{dateFull(a.changed_at)}</Td><Td>{a.record_id}</Td>
                    <Td className="font-mono text-xs">{JSON.stringify(a.old_data)}</Td><Td className="font-mono text-xs">{JSON.stringify(a.new_data)}</Td></tr>))}
                </tbody>
              </Table>
            )}
          </Section>
        </>
      )}
    </Page>
  );
}
