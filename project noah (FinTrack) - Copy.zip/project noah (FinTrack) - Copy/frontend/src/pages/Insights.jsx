import { useState } from "react";
import { api } from "../api";
import { useApi } from "../hooks";
import { dateFull, money, moneyRound, monthLong, monthShort } from "../format";
import Bars from "../Bars.jsx";
import { Btn, Empty, ErrorMsg, Loading, Notice, Page, Section, Table, Td, Th, cx } from "../ui.jsx";

const SEVERITY = {
  warning: "border-warn bg-warn-soft",
  positive: "border-inflow bg-good-soft",
  info: "border-brand bg-brand-soft",
};

function InsightList({ content }) {
  return (
    <div>
      {content.headline && <p className="mb-3 font-display text-xl font-semibold leading-snug">{content.headline}</p>}
      <ul className="space-y-2">
        {content.insights.map((i, n) => (
          <li key={n} className={cx("rounded-md border-l-4 px-4 py-3", SEVERITY[i.severity] ?? SEVERITY.info)}>
            <p className="font-semibold">{i.title}{i.category && <span className="ml-2 text-xs font-normal text-muted">{i.category}</span>}</p>
            <p className="text-sm">{i.detail}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Insights() {
  const fc = useApi(() => api("/api/insights/forecast?months=3"));
  const hist = useApi(() => api("/api/insights/history?limit=5"));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  async function generate() {
    setBusy(true); setError(null);
    try { await api("/api/insights/generate", { method: "POST" }); hist.reload(); }
    catch (e) { setError(e.message); } finally { setBusy(false); }
  }

  const f = fc.data;
  const ok = f?.status === "ok";
  const uniqueHistory = [];
  const seenContent = new Set();
  for (const entry of hist.data ?? []) {
    const fingerprint = JSON.stringify(entry.content);
    if (!seenContent.has(fingerprint)) {
      seenContent.add(fingerprint);
      uniqueHistory.push(entry);
    }
  }
  const last = uniqueHistory[0];

  return (
    <Page title="Insights" subtitle="A statistical forecast and concise observations based on your recent financial activity.">
      <Section title="Spending forecast" hint={ok ? "next 3 months" : undefined}>
        {fc.loading && !f ? <Loading /> : fc.error ? <ErrorMsg error={fc.error} /> : !ok ? (
          <Empty>The forecast needs at least two complete months of spending. Add or import more history.</Empty>
        ) : (
          <div className="space-y-5">
            <p className="text-sm">
              Projected spending for <strong>{monthLong(f.forecast_months[0])}</strong>:{" "}
              <strong className="font-display text-xl tabular-nums">{money(f.this_month.projected)}</strong>
              <span className="text-muted"> ({money(f.this_month.spent_so_far)} so far
                {f.this_month.budget_total != null && `, budgets total ${money(f.this_month.budget_total)}`})</span>
            </p>

            <Bars label="Monthly spending: past months and forecast" format={moneyRound}
                  items={[
                    ...f.history_months.map((m, i) => ({ label: monthShort(m), series: [{ value: f.total.history[i], tone: "outflow" }] })),
                    ...f.forecast_months.map((m, i) => ({ label: monthShort(m), series: [{
                      value: f.total.forecast[i], low: f.total.low[i], high: f.total.high[i], tone: "brand", forecast: true }] })),
                  ]} />
            <p className="text-xs text-muted">
              Solid bars are actual spending. Dashed bars are forecasts and the line shows a typical range (one standard deviation).
              Method: {f.method === "damped_trend" ? "recent average plus a damped linear trend, per category" : "flat average (not enough history for a trend)"}.
              Calculated from your data, not by AI.
            </p>

            <Table>
              <thead><tr><Th>Category</Th><Th className="text-right">Last month</Th><Th className="text-right">So far</Th><Th className="text-right">Projected</Th>
                <Th className="text-right">Next month</Th><Th className="text-right">Budget</Th><Th /></tr></thead>
              <tbody>
                {f.categories.map((c) => (
                  <tr key={c.category_id}>
                    <Td className="font-medium">{c.category}</Td>
                    <Td className="text-right">{money(c.history[c.history.length - 1])}</Td>
                    <Td className="text-right text-muted">{money(c.spent_so_far)}</Td>
                    <Td className="text-right font-semibold">{money(c.projected_this_month)}</Td>
                    <Td className="text-right">{money(c.forecast[1] ?? c.forecast[0])}</Td>
                    <Td className="text-right text-muted">{c.budget_limit != null ? money(c.budget_limit) : "—"}</Td>
                    <Td>{c.over_budget_risk && <span className="rounded bg-bad-soft px-1.5 py-0.5 text-[11px] font-semibold text-outflow">May exceed budget</span>}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        )}
      </Section>

      <Section title="Financial insights" hint="distinct observations based on budgets, spending, and goals"
               actions={<Btn onClick={generate} disabled={busy}>{busy ? "Updating…" : last ? "Refresh insights" : "Generate insights"}</Btn>}>
        <ErrorMsg error={error} />
        {hist.loading && !hist.data ? <Loading /> : !last ? (
          !error && <Empty>No insights yet. Press the button to generate your first set.</Empty>
        ) : (
          <div className="space-y-5">
            <p className="text-xs text-muted">Updated {dateFull(last.created_at)} · {last.model === "server-analysis-v1" ? "calculated by this server" : `generated by ${last.model}`}</p>
            <InsightList content={last.content} />
            {uniqueHistory.length > 1 && (
              <details className="text-sm">
                <summary className="cursor-pointer font-semibold text-brand">Earlier distinct insights ({uniqueHistory.length - 1})</summary>
                <div className="mt-4 space-y-8">
                  {uniqueHistory.slice(1).map((h) => (
                    <div key={h.id}><p className="mb-2 text-xs text-muted">{dateFull(h.created_at)}</p><InsightList content={h.content} /></div>
                  ))}
                </div>
              </details>
            )}
          </div>
        )}
        <div className="mt-4"><Notice tone="info">These insights are calculated on your server from category totals, budgets, goals, and forecasts. They do not use account names, merchants, or transaction descriptions.</Notice></div>
      </Section>
    </Page>
  );
}
