import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../store.jsx";
import { Btn, ErrorMsg, Field, Input, Notice } from "../ui.jsx";

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState("login");
  const [registrationToken, setRegistrationToken] = useState("");
  const [registrationPhone, setRegistrationPhone] = useState("");
  const [resetToken, setResetToken] = useState("");
  const [f, setF] = useState({ full_name: "", email: "", phone_number: "", password: "", password_confirm: "", code: "" });
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/" replace />;
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const title = {
    login: "Sign in",
    register: "Create your account",
    verify: "Verify your phone",
    forgot: "Reset your password",
    sms_reset: "Enter your text code",
  }[mode];

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setError(null); setNotice("");
    try {
      if (mode === "login") {
        await login(f.email, f.password);
        navigate("/");
      } else if (mode === "register") {
        const result = await api("/api/auth/register", {
          method: "POST",
          body: { full_name: f.full_name, email: f.email, password: f.password, phone_number: f.phone_number },
        });
        setRegistrationToken(result.registration_token);
        setRegistrationPhone(f.phone_number);
        setMode("verify");
        setNotice(`A one-time code was sent to ${f.phone_number}. It expires in 10 minutes.`);
      } else if (mode === "verify") {
        await api("/api/auth/register/verify", {
          method: "POST",
          body: { registration_token: registrationToken, code: f.code },
        });
        await login(f.email, f.password);
        navigate("/");
      } else if (mode === "forgot") {
        const result = await api("/api/auth/password-reset/sms/request", {
          method: "POST", body: { phone_number: f.phone_number },
        });
        setResetToken(result.reset_token);
        setMode("sms_reset");
        setNotice("If that number is linked to an account, a text code will arrive shortly. The code expires in 10 minutes.");
      } else if (mode === "sms_reset") {
        if (f.password !== f.password_confirm) throw new Error("The passwords do not match.");
        const result = await api("/api/auth/password-reset/sms/confirm", {
          method: "POST",
          body: { reset_token: resetToken, code: f.code, password: f.password },
        });
        setF({ ...f, email: result.email, password: "", password_confirm: "", code: "" });
        setResetToken("");
        setMode("login");
        setNotice(`Your password has been changed. The account email is ${result.email}. Sign in with your new password.`);
      }
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  function changeMode(nextMode) {
    setMode(nextMode);
    setError(null);
    setNotice("");
  }

  return (
    <div className="grid min-h-screen md:grid-cols-[1.1fr_1fr]">
      <div className="flex flex-col justify-between bg-ink p-8 text-white md:p-12">
        <span className="font-display text-xl font-bold tracking-tight">FinTrack</span>
        <div className="py-12">
          <p className="font-display text-4xl font-bold leading-tight tracking-tight md:text-5xl">
            Know where it went.<br />See where it is going.
          </p>
          <p className="mt-4 max-w-md text-white/70">
            Accounts, budgets, goals and investments in one place. Paste a bank statement and your local AI
            sorts uncategorised lines, then forecasts next month's spending.
          </p>
        </div>
        <p className="text-xs text-white/50">Self-hosted finance tracking. Never enter your bank password; FinTrack does not connect to your bank.</p>
      </div>

      <div className="flex items-center justify-center p-6 md:p-12">
        <form onSubmit={submit} className="w-full max-w-sm space-y-4">
          <h1 className="font-display text-2xl font-bold">{title}</h1>

          {mode === "register" && (
            <>
              <Field label="Full name"><Input required value={f.full_name} onChange={set("full_name")} autoComplete="name" /></Field>
              <Field label="Phone number (include country code)">
                <Input required type="tel" value={f.phone_number} onChange={set("phone_number")} autoComplete="tel" placeholder="+639171234567" pattern="\+[1-9][0-9]{7,14}" />
              </Field>
              <p className="-mt-2 text-xs text-muted">We’ll text one code to confirm this number during signup and keep it for password recovery. Carrier charges may apply.</p>
            </>
          )}

          {(mode === "login" || mode === "register") && (
            <Field label="Email"><Input required type="email" value={f.email} onChange={set("email")} autoComplete="email" /></Field>
          )}

          {mode === "forgot" && (
            <>
              <Field label="Verified phone number (include country code)">
                <Input required type="tel" value={f.phone_number} onChange={set("phone_number")} autoComplete="tel" placeholder="+639171234567" pattern="\+[1-9][0-9]{7,14}" />
              </Field>
              <p className="-mt-2 text-xs text-muted">Enter the number you verified when creating your account.</p>
            </>
          )}

          {(mode === "login" || mode === "register" || mode === "sms_reset") && (
            <Field label={mode === "register" || mode === "sms_reset" ? "Password (8+ characters)" : "Password"}>
              <Input required type="password" minLength={mode === "register" || mode === "sms_reset" ? 8 : undefined} maxLength={72}
                     value={f.password} onChange={set("password")}
                     autoComplete={mode === "login" ? "current-password" : "new-password"} />
            </Field>
          )}

          {mode === "sms_reset" && (
            <>
              <Field label="Text message code">
                <Input required inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{4,10}"
                       value={f.code} onChange={set("code")} />
              </Field>
              <Field label="Confirm new password">
                <Input required type="password" minLength={8} maxLength={72} value={f.password_confirm}
                       onChange={set("password_confirm")} autoComplete="new-password" />
              </Field>
            </>
          )}

          {mode === "verify" && (
            <>
              <p className="text-sm text-muted">Enter the code sent to {registrationPhone}.</p>
              <Field label="Text message code">
                <Input required inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{4,10}"
                       value={f.code} onChange={set("code")} />
              </Field>
            </>
          )}

          <ErrorMsg error={error} />
          {notice && <Notice tone="good">{notice}</Notice>}
          <Btn type="submit" disabled={busy || (mode === "verify" && !registrationToken) || (mode === "sms_reset" && !resetToken)} className="w-full">
            {busy ? "Please wait…" : mode === "login" ? "Sign in" : mode === "register" ? "Send signup code" : mode === "verify" ? "Verify and create account" : mode === "forgot" ? "Send reset code" : "Reset password"}
          </Btn>

          {mode === "login" && (
            <p className="text-sm text-muted">
              <button type="button" className="font-semibold text-brand underline" onClick={() => changeMode("forgot")}>Forgot password?</button>
            </p>
          )}
          {(mode === "login" || mode === "register") && (
            <p className="text-sm text-muted">
              {mode === "login" ? "New here? " : "Already registered? "}
              <button type="button" className="font-semibold text-brand underline"
                      onClick={() => changeMode(mode === "login" ? "register" : "login")}>
                {mode === "login" ? "Create an account" : "Sign in"}
              </button>
            </p>
          )}
          {(mode === "forgot" || mode === "sms_reset") && (
            <p className="text-sm text-muted">
              <button type="button" className="font-semibold text-brand underline" onClick={() => changeMode("login")}>Back to sign in</button>
            </p>
          )}
          {mode === "verify" && (
            <p className="text-sm text-muted">
              <button type="button" className="font-semibold text-brand underline" onClick={() => { setRegistrationToken(""); changeMode("register"); }}>Use a different number</button>
            </p>
          )}
        </form>
      </div>
    </div>
  );
}
