import { Link } from "react-router-dom";
import { api } from "../api";
import { useApi } from "../hooks";
import { monthISO, monthLong, monthShort, money, moneyRound, dateShort } from "../format";
import { useAuth } from "../store.jsx";
import Bars from "../Bars.jsx";
import { Empty, ErrorMsg, Loading, Page, Progress, Section, Stats, cx } from "../ui.jsx";

export default function Dashboard() {
  const { user } = useAuth();
  const ov = useApi(() => api("/api/insights/overview"));
  const budgets = useApi(() => api(`/api/budgets?month=${monthISO()}`));
  const goals = useApi(() => api("/api/goals"));

  if (ov.loading && !ov.data) return <Loading />;
  if (ov.error) return <ErrorMsg error={ov.error} />;
  const d = ov.data;
  const thisMonth = d.cashflow.find((c) => c.month === monthISO());
  const income = Number(thisMonth?.income ?? 0), spend = Number(thisMonth?.expenses ?? 0);
  const rate = income > 0 ? Math.round(((income - spend) / income) * 100) : null;
  const activeGoals = (goals.data ?? []).filter((g) => g.status === "active").slice(0, 3);

  return (
    <Page title={`Hello, ${user.full_name.split(" ")[0]}`} subtitle={monthLong(monthISO())}>
      <div>
        <p className="text-sm font-semibold text-muted">Net worth</p>
        <p className="font-display text-5xl font-bold tracking-tight tabular-nums md:text-6xl">{money(d.net_worth)}</p>
        <p className="mt-1 text-sm text-muted">
          {money(d.bank_total)} in bank accounts · {money(d.portfolio_value)} invested
        </p>
      </div>

      <Stats items={[
        { label: "Income this month", value: money(income), className: "text-inflow" },
        { label: "Spent this month", value: money(spend), className: "text-outflow" },
        { label: "Net", value: money(income - spend) },
        { label: "Savings rate", value: rate == null ? "n/a" : `${rate}%`, note: rate == null ? "no income yet" : undefined },
      ]} />

      <Section title="Cash flow" hint="last 6 months"
               actions={<span className="flex gap-3 text-xs text-muted">
                 <span><i className="mr-1 inline-block size-2.5 rounded-sm bg-inflow" />In</span>
                 <span><i className="mr-1 inline-block size-2.5 rounded-sm bg-outflow" />Out</span></span>}>
        {d.cashflow.length === 0 ? <Empty>No transactions yet.</Empty> : (
          <Bars label="Income and spending per month" format={moneyRound}
                items={d.cashflow.map((c) => ({
                  label: monthShort(c.month),
                  series: [{ value: Number(c.income), tone: "inflow" }, { value: Number(c.expenses), tone: "outflow" }],
                }))} />
        )}
      </Section>

      <div className="grid gap-9 md:grid-cols-2">
        <Section title="Budgets" actions={<Link className="text-sm font-semibold text-brand" to="/budgets">Manage</Link>}>
          {budgets.loading ? <Loading /> : (budgets.data ?? []).length === 0 ? <Empty>No budgets for this month.</Empty> : (
            <ul className="space-y-3">
              {budgets.data.slice(0, 5).map((b) => (
                <li key={b.budget_id}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span className="font-medium">{b.category}</span>
                    <span className={cx("tabular-nums", Number(b.pct_used) >= 100 ? "font-semibold text-outflow" : "text-muted")}>
                      {money(b.spent)} / {money(b.limit_amount)}
                    </span>
                  </div>
                  <Progress pct={Number(b.pct_used)} />
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section title="Goals" actions={<Link className="text-sm font-semibold text-brand" to="/goals">Manage</Link>}>
          {goals.loading ? <Loading /> : activeGoals.length === 0 ? <Empty>No active goals.</Empty> : (
            <ul className="space-y-3">
              {activeGoals.map((g) => (
                <li key={g.goal_id}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span className="font-medium">{g.name}</span>
                    <span className="tabular-nums text-muted">{money(g.saved_amount)} of {money(g.target_amount)}</span>
                  </div>
                  <Progress pct={Number(g.pct_complete)} tone="bg-inflow" />
                  {g.target_date && <p className="mt-0.5 text-xs text-muted">
                    by {dateShort(g.target_date)}{g.required_monthly != null && ` · ${money(g.required_monthly)}/month needed`}</p>}
                </li>
              ))}
            </ul>
          )}
        </Section>
      </div>

      <Section title="Where it went this month">
        {d.top_categories_this_month.length === 0 ? <Empty>No spending recorded this month.</Empty> : (
          <ul className="divide-y divide-line rounded-lg border border-line bg-surface">
            {d.top_categories_this_month.map((c) => (
              <li key={c.category} className="flex justify-between px-4 py-2.5 text-sm">
                <span>{c.category}</span><span className="font-semibold tabular-nums">{money(c.total)}</span>
              </li>
            ))}
          </ul>
        )}
      </Section>
    </Page>
  );
}
