import { useState } from "react";
import { api } from "../api";
import { useApi } from "../hooks";
import { money, todayISO } from "../format";
import { Amount, Btn, Empty, ErrorMsg, Field, Input, Loading, Notice, Page, Section, Select, Table, Td, Th } from "../ui.jsx";

const CURRENCIES = [
  ["PHP", "Philippine peso"], ["USD", "US dollar"], ["JPY", "Japanese yen"], ["EUR", "Euro"],
  ["GBP", "British pound"], ["SGD", "Singapore dollar"], ["AUD", "Australian dollar"],
  ["CAD", "Canadian dollar"], ["CNY", "Chinese yuan"], ["HKD", "Hong Kong dollar"],
  ["KRW", "South Korean won"], ["INR", "Indian rupee"], ["MYR", "Malaysian ringgit"],
  ["IDR", "Indonesian rupiah"], ["THB", "Thai baht"], ["CHF", "Swiss franc"], ["NZD", "New Zealand dollar"],
];

const blankForm = { institution_id: "", account_type_id: "", name: "", last4: "", opening_balance: "0", currency_code: "PHP", fx_rate_to_php: "1" };

export default function Accounts() {
  const accounts = useApi(() => api("/api/accounts"));
  const institutions = useApi(() => api("/api/institutions"));
  const types = useApi(() => api("/api/account-types"));
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);
  const [form, setForm] = useState(blankForm);
  const [tf, setTf] = useState({ from_account_id: "", to_account_id: "", from_amount: "", to_amount: "", txn_date: todayISO(), note: "" });

  const run = async (fn, msg) => {
    setError(null); setNotice(null);
    try { await fn(); if (msg) setNotice(msg); accounts.reload(); } catch (e) { setError(e.message); }
  };

  const list = accounts.data ?? [];
  const bank = list.filter((a) => !a.is_investment && a.is_active);
  const total = bank.reduce((s, a) => s + Number(a.current_balance_php), 0);
  const defaultType = (types.data ?? []).find((t) => t.name.toLowerCase() === "cash")
    ?? (types.data ?? []).find((t) => !t.is_investment);
  const typeValue = form.account_type_id || String(defaultType?.id ?? "");
  const selectedType = (types.data ?? []).find((t) => String(t.id) === String(typeValue)) ?? defaultType;
  const last4AlreadyUsed = form.last4.length === 4
    && list.some((a) => String(a.last4 ?? "").trim() === form.last4);
  const fromId = tf.from_account_id || String(bank[0]?.account_id ?? "");
  const fromAccount = bank.find((a) => String(a.account_id) === String(fromId)) ?? bank[0];
  const toDefault = bank.find((a) => a.account_id !== fromAccount?.account_id) ?? bank[1];
  const toId = tf.to_account_id || String(toDefault?.account_id ?? "");
  const toAccount = bank.find((a) => String(a.account_id) === String(toId)) ?? toDefault;
  const sameCurrency = fromAccount && toAccount && fromAccount.currency_code === toAccount.currency_code;

  const addAccount = (e) => {
    e.preventDefault();
    if (last4AlreadyUsed) return;
    run(async () => {
      await api("/api/accounts", { method: "POST", body: {
        institution_id: Number(form.institution_id || institutions.data?.[0]?.id),
        account_type_id: Number(typeValue || types.data?.[0]?.id),
        name: form.name, last4: form.last4 || null, opening_balance: Number(form.opening_balance || 0),
        currency_code: form.currency_code,
        fx_rate_to_php: form.currency_code === "PHP" ? 1 : Number(form.fx_rate_to_php),
      } });
      setForm({ ...blankForm, account_type_id: String(defaultType?.id ?? ""), institution_id: form.institution_id });
    }, "Account added.");
  };

  const doTransfer = (e) => {
    e.preventDefault();
    run(async () => {
      await api("/api/accounts/transfer", { method: "POST", body: {
        from_account_id: Number(fromId), to_account_id: Number(toId),
        from_amount: Number(tf.from_amount), to_amount: Number(sameCurrency ? tf.from_amount : tf.to_amount),
        txn_date: tf.txn_date, note: tf.note || null,
      } });
      setTf({ ...tf, from_amount: "", to_amount: "", note: "" });
    }, "Transfer recorded.");
  };

  const updateRate = (a) => {
    const value = prompt(`Current PHP value of 1 ${a.currency_code}. This rate is shared by all your ${a.currency_code} accounts:`, String(a.fx_rate_to_php));
    if (value === null) return;
    const rate = Number(value);
    if (!Number.isFinite(rate) || rate <= 0) { setError("Enter a rate greater than zero."); return; }
    run(() => api(`/api/accounts/${a.account_id}`, { method: "PUT", body: { fx_rate_to_php: rate } }), `${a.currency_code} rate updated for your ${a.currency_code} accounts.`);
  };

  return (
    <Page title="Accounts" subtitle="Each account keeps its own currency. Balances and reports show the PHP equivalent using the rates you enter.">
      <ErrorMsg error={error || accounts.error} />
      {notice && <Notice tone="good">{notice}</Notice>}

      <Section title="Your accounts" hint={bank.length ? `${money(total)} total in bank and cash accounts` : undefined}>
        {accounts.loading && !accounts.data ? <Loading /> : list.length === 0 ? <Empty>No accounts yet. Add one below.</Empty> : (
          <Table>
            <thead><tr><Th>Account</Th><Th>Institution</Th><Th>Type</Th><Th className="text-right">Balance</Th><Th /></tr></thead>
            <tbody>
              {list.map((a) => (
                <tr key={a.account_id} className={a.is_active ? "" : "opacity-50"}>
                  <Td><span className="font-semibold">{a.name}</span>{a.last4 && <span className="ml-2 text-xs text-muted">••{a.last4}</span>}</Td>
                  <Td>{a.institution}</Td>
                  <Td>{a.account_type}</Td>
                  <Td className="text-right">
                    {a.is_investment ? <span className="text-xs text-muted">see Portfolio</span> : (
                      <><div><Amount value={a.current_balance} signed={false} currency={a.currency_code} /></div>
                        {a.currency_code !== "PHP" && <div className="text-xs text-muted">≈ {money(a.current_balance_php)} at {a.fx_rate_to_php}</div>}</>
                    )}
                  </Td>
                  <Td className="whitespace-nowrap text-right">
                    {!a.is_investment && a.currency_code !== "PHP" && <Btn variant="ghost" className="mr-1 px-2 py-1 text-xs" onClick={() => updateRate(a)}>Update rate</Btn>}
                    <Btn variant="ghost" className="mr-1 px-2 py-1 text-xs"
                         onClick={() => run(() => api(`/api/accounts/${a.account_id}`, { method: "PUT", body: { is_active: !a.is_active } }))}>
                      {a.is_active ? "Archive" : "Restore"}</Btn>
                    <Btn variant="danger" className="px-2 py-1 text-xs"
                         onClick={() => confirm(`Delete “${a.name}” and ALL its transactions? This cannot be undone.`) &&
                           run(() => api(`/api/accounts/${a.account_id}`, { method: "DELETE" }), "Account deleted.")}>Delete</Btn>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Section>

      <Section title="Add an account">
        <form onSubmit={addAccount} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
          <Field label="Institution" className="lg:col-span-2">
            <Select value={form.institution_id || institutions.data?.[0]?.id || ""} onChange={(e) => setForm({ ...form, institution_id: e.target.value })}>
              {(institutions.data ?? []).map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</Select></Field>
          <Field label="Type">
            <Select value={typeValue} onChange={(e) => {
              const value = e.target.value;
              const type = (types.data ?? []).find((t) => String(t.id) === value);
              setForm({ ...form, account_type_id: value, ...(type?.is_investment ? { currency_code: "PHP", fx_rate_to_php: "1" } : {}) });
            }}>
              {(types.data ?? []).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</Select></Field>
          <Field label="Name"><Input required maxLength={80} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Currency">
            <Select disabled={Boolean(selectedType?.is_investment)} value={form.currency_code} onChange={(e) => {
              const existing = list.find((a) => a.currency_code === e.target.value);
              setForm({ ...form, currency_code: e.target.value,
                fx_rate_to_php: e.target.value === "PHP" ? "1" : String(existing?.fx_rate_to_php ?? "") });
            }}>
              {CURRENCIES.map(([code, label]) => <option key={code} value={code}>{code} · {label}</option>)}</Select></Field>
          {selectedType?.is_investment && <p className="text-xs text-muted sm:col-span-2 lg:col-span-6">Investment accounts use PHP for Portfolio prices. Choose Checking, Savings, or Cash to add an account in another currency.</p>}
          <Field label="Last 4 digits">
            <Input pattern="\d{4}" maxLength={4} placeholder="optional" value={form.last4} onChange={(e) => setForm({ ...form, last4: e.target.value })} />
            {last4AlreadyUsed && <span className="mt-1 block text-xs text-outflow" role="alert">Those digits are already used on another account.</span>}
          </Field>
          <Field label={`Opening balance (${form.currency_code})`}><Input type="number" step="0.01" value={form.opening_balance} onChange={(e) => setForm({ ...form, opening_balance: e.target.value })} /></Field>
          {form.currency_code !== "PHP" && !selectedType?.is_investment && <Field label={`PHP per 1 ${form.currency_code}`}>
            <Input required type="number" min="0.00000001" step="0.00000001" value={form.fx_rate_to_php} onChange={(e) => setForm({ ...form, fx_rate_to_php: e.target.value })} />
          </Field>}
          <div className="sm:col-span-2 lg:col-span-6">
            {form.currency_code !== "PHP" && <p className="mb-2 text-xs text-muted">Enter the current exchange rate yourself. FinTrack does not download rates automatically.</p>}
            <Btn type="submit" disabled={!institutions.data?.length || !types.data?.length || last4AlreadyUsed}>Add account</Btn>
          </div>
        </form>
      </Section>

      {bank.length >= 2 && (
        <Section title="Transfer or convert between accounts" hint="Same-currency transfers use the same amount on each side. For a conversion, enter what left and what arrived.">
          <form onSubmit={doTransfer} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            <Field label="From"><Select value={fromId} onChange={(e) => {
              const next = bank.find((a) => String(a.account_id) === e.target.value);
              setTf({ ...tf, from_account_id: e.target.value,
                to_amount: next?.currency_code === toAccount?.currency_code ? tf.from_amount : "" });
            }}>
              {bank.map((a) => <option key={a.account_id} value={a.account_id}>{a.name} · {a.currency_code}</option>)}</Select></Field>
            <Field label="To"><Select value={toId} onChange={(e) => {
              const account = bank.find((a) => String(a.account_id) === e.target.value);
              setTf({ ...tf, to_account_id: e.target.value,
                to_amount: fromAccount?.currency_code === account?.currency_code ? tf.from_amount : "" });
            }}>
              {bank.map((a) => <option key={a.account_id} value={a.account_id}>{a.name} · {a.currency_code}</option>)}</Select></Field>
            <Field label={`Amount sent (${fromAccount?.currency_code ?? "PHP"})`}><Input required type="number" min="0.01" step="0.01" value={tf.from_amount} onChange={(e) => setTf({ ...tf, from_amount: e.target.value, ...(sameCurrency ? { to_amount: e.target.value } : {}) })} /></Field>
            {sameCurrency ? <div className="self-end pb-2 text-sm text-muted">Same amount received ({toAccount?.currency_code})</div> :
              <Field label={`Amount received (${toAccount?.currency_code ?? "PHP"})`}><Input required type="number" min="0.01" step="0.01" value={tf.to_amount} onChange={(e) => setTf({ ...tf, to_amount: e.target.value })} /></Field>}
            <Field label="Date"><Input required type="date" value={tf.txn_date} onChange={(e) => setTf({ ...tf, txn_date: e.target.value })} /></Field>
            <Field label="Note"><Input maxLength={100} placeholder="optional" value={tf.note} onChange={(e) => setTf({ ...tf, note: e.target.value })} /></Field>
            {!sameCurrency && Number(tf.from_amount) > 0 && Number(tf.to_amount) > 0 &&
              <p className="self-end pb-2 text-sm text-muted">Effective rate: {(Number(tf.to_amount) / Number(tf.from_amount)).toFixed(6)} {toAccount.currency_code} per 1 {fromAccount.currency_code}.</p>}
            <div className="sm:col-span-2 lg:col-span-5"><Btn type="submit" disabled={!fromAccount || !toAccount || fromId === toId}>Record transfer</Btn></div>
          </form>
        </Section>
      )}
    </Page>
  );
}
