import { useState } from "react";
import { api, qs } from "../api";
import { useApi } from "../hooks";
import { dateFull, money, signedMoneyCurrency, todayISO } from "../format";
import {
  Amount, Btn, Empty, ErrorMsg, Field, Input, Loading, Notice, Page, Section, Select,
  SourceBadge, Table, Td, Textarea, Th,
} from "../ui.jsx";

const PAGE = 25;
const KIND_LABEL = { expense: "Expenses", income: "Income", transfer: "Transfers" };

// Explains, in plain words, what happened when the AI was (or wasn't) involved.
const aiNote = (status) =>
  status === "unavailable" ? " Local AI is offline or its model is missing, so only keyword rules were used."
  : status === "error" ? " The local AI call failed, so only keyword rules were used."
  : "";

function CategorySelect({ categories, value, onChange, children, ...rest }) {
  return (
    <Select value={value ?? ""} onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))} {...rest}>
      {children}
      {Object.entries(KIND_LABEL).map(([kind, label]) => (
        <optgroup key={kind} label={label}>
          {categories.filter((c) => c.kind === kind).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </optgroup>
      ))}
    </Select>
  );
}

// ---------------------------------------------------------------- add one
function AddTransaction({ accounts, categories, onDone, setError, setNotice }) {
  const [f, setF] = useState({ account_id: "", txn_date: todayISO(), description: "", amount: "", flow: "expense", category_id: null });
  const [busy, setBusy] = useState(false);
  const accountId = f.account_id || String(accounts[0]?.account_id ?? "");
  const account = accounts.find((a) => String(a.account_id) === String(accountId));
  const currency = account?.currency_code ?? "PHP";
  const rate = currency === "PHP" ? 1 : Number(f.fx_rate_to_php || account?.fx_rate_to_php || 1);

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setError(null); setNotice(null);
    try {
      const amount = Math.abs(Number(f.amount)) * (f.flow === "expense" ? -1 : 1);
      const res = await api("/api/transactions", { method: "POST", body: {
        account_id: Number(accountId), txn_date: f.txn_date, description: f.description, amount,
        fx_rate_to_php: rate, category_id: f.category_id } });
      const how = { ai: "by AI", rule: "by a keyword rule", default: "(needs review)", manual: "" }[res.category_source];
      setNotice(`Added. Category: ${res.category} ${how}.${aiNote(res.ai_status)}`);
      setF({ ...f, description: "", amount: "", category_id: null });
      onDone();
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  return (
    <form onSubmit={submit} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
      <Field label="Account"><Select value={accountId} onChange={(e) => {
        const next = accounts.find((a) => String(a.account_id) === e.target.value);
        setF({ ...f, account_id: e.target.value, fx_rate_to_php: String(next?.fx_rate_to_php ?? 1) });
      }}>
        {accounts.map((a) => <option key={a.account_id} value={a.account_id}>{a.name} · {a.currency_code}</option>)}</Select></Field>
      <Field label="Date"><Input required type="date" value={f.txn_date} onChange={(e) => setF({ ...f, txn_date: e.target.value })} /></Field>
      <Field label="Description" className="lg:col-span-2">
        <Input required maxLength={255} placeholder="e.g. STARBUCKS #1042" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
      <Field label="Type"><Select value={f.flow} onChange={(e) => setF({ ...f, flow: e.target.value })}>
        <option value="expense">Money out</option><option value="income">Money in</option></Select></Field>
      <Field label={`Amount (${currency})`}><Input required type="number" min="0.01" step="0.01" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} /></Field>
      {currency !== "PHP" && <Field label={`PHP per 1 ${currency}`}>
        <Input required type="number" min="0.00000001" step="0.00000001" value={f.fx_rate_to_php || account?.fx_rate_to_php || ""} onChange={(e) => setF({ ...f, fx_rate_to_php: e.target.value })} />
      </Field>}
      <Field label="Category" className="lg:col-span-2">
        <CategorySelect categories={categories} value={f.category_id} onChange={(v) => setF({ ...f, category_id: v })}>
          <option value="">Auto: rules, then AI</option>
        </CategorySelect></Field>
      <div className="flex items-end lg:col-span-4"><Btn type="submit" disabled={busy || !accountId}>{busy ? "Categorising…" : "Add transaction"}</Btn></div>
    </form>
  );
}

// ---------------------------------------------------------------- import raw statement lines
// Accepts lines like:  2026-09-28, STARBUCKS #1234 MANILA, -4.50   (date, description, amount)
function parseLines(text) {
  const rows = []; let skipped = 0;
  text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).forEach((line) => {
    const parts = line.split(",").map((p) => p.trim());
    const date = parts[0]?.replace(/\//g, "-");
    const raw = (parts[parts.length - 1] ?? "").replace(/[$\s]/g, "");
    const amount = raw.startsWith("(") ? -parseFloat(raw.replace(/[()]/g, "")) : parseFloat(raw);
    const description = parts.slice(1, -1).join(", ");
    if (parts.length >= 3 && /^\d{4}-\d{2}-\d{2}$/.test(date) && description && Number.isFinite(amount) && amount !== 0)
      rows.push({ txn_date: date, description: description.slice(0, 255), amount });
    else skipped += 1;
  });
  return { rows, skipped };
}

function ImportPanel({ accounts, categories, onDone, setError, setNotice }) {
  const [text, setText] = useState("");
  const [accountId, setAccountId] = useState("");
  const [preview, setPreview] = useState(null);
  const [busy, setBusy] = useState(false);
  const [fxRate, setFxRate] = useState("");
  const acct = accountId || String(accounts[0]?.account_id ?? "");
  const account = accounts.find((a) => String(a.account_id) === String(acct));
  const currency = account?.currency_code ?? "PHP";
  const rate = currency === "PHP" ? 1 : Number(fxRate || account?.fx_rate_to_php || 1);
  const catName = (id) => categories.find((c) => c.id === id)?.name ?? "?";

  async function categorise() {
    setError(null); setNotice(null);
    const { rows, skipped } = parseLines(text);
    if (!rows.length) { setError("No valid lines found. Use: YYYY-MM-DD, description, amount"); return; }
    if (rows.length > 200) { setError("Please import at most 200 lines at a time."); return; }
    setBusy(true);
    try {
      const res = await api("/api/transactions/classify", { method: "POST", body: {
        rows: rows.map(({ description, amount }) => ({ description, amount, fx_rate_to_php: rate }))
      } });
      setPreview({ skipped, ai_status: res.ai_status, rows: rows.map((r, i) => ({ ...r, fx_rate_to_php: rate, ...res.results[i] })) });
    } catch (e) { setError(e.message); } finally { setBusy(false); }
  }

  const edit = (i, category_id) =>
    setPreview((p) => ({ ...p, rows: p.rows.map((r, j) => (j === i ? { ...r, category_id, category_source: "manual", ai_confidence: null } : r)) }));

  async function save() {
    setBusy(true); setError(null);
    try {
      const res = await api("/api/transactions/import", { method: "POST", body: { account_id: Number(acct), rows: preview.rows } });
      setNotice(`Imported ${res.inserted} transactions.`);
      setPreview(null); setText(""); onDone();
    } catch (e) { setError(e.message); } finally { setBusy(false); }
  }

  const low = preview?.rows.filter((r) => r.category_source === "default" || (r.ai_confidence != null && r.ai_confidence < 0.6)).length ?? 0;

  return (
    <div className="space-y-3">
      {!preview ? (
        <>
          <Field label="Paste statement lines: date, description, amount (negative = money out)">
            <Textarea rows={6} value={text} onChange={(e) => setText(e.target.value)}
              placeholder={"2026-09-28, STARBUCKS #1234 MANILA, -4.50\n2026-09-29, ACME CORP PAYROLL, 3200.00\n2026-09-30, DR LIM DENTAL ASSOC, -85.00"} />
          </Field>
          <div className="flex flex-wrap items-end gap-3">
            <Field label="Import into"><Select value={acct} onChange={(e) => {
              const next = accounts.find((a) => String(a.account_id) === e.target.value);
              setAccountId(e.target.value); setFxRate(String(next?.fx_rate_to_php ?? 1));
            }}>
              {accounts.map((a) => <option key={a.account_id} value={a.account_id}>{a.name} · {a.currency_code}</option>)}</Select></Field>
            {currency !== "PHP" && <Field label={`PHP per 1 ${currency}`}>
              <Input required type="number" min="0.00000001" step="0.00000001" value={fxRate || account?.fx_rate_to_php || ""} onChange={(e) => setFxRate(e.target.value)} />
            </Field>}
            <Btn onClick={categorise} disabled={busy || !text.trim() || !acct}>{busy ? "Categorising…" : "Categorise & preview"}</Btn>
          </div>
          {currency !== "PHP" && <p className="text-xs text-muted">This rate is applied to each imported row. Enter an historical rate here when the statement is from an earlier period.</p>}
        </>
      ) : (
        <>
          {preview.skipped > 0 && <Notice tone="warn">{preview.skipped} line(s) could not be read and were skipped.</Notice>}
          {aiNote(preview.ai_status) && <Notice tone="warn">{aiNote(preview.ai_status).trim()}</Notice>}
          <p className="text-sm text-muted">
            Review the categories below. Change any you disagree with, then import.
            {low > 0 && <span className="font-semibold text-warn"> {low} need a closer look.</span>}
          </p>
          <Table>
            <thead><tr><Th>Date</Th><Th>Description</Th><Th className="text-right">Amount ({currency})</Th><Th>Category</Th><Th /></tr></thead>
            <tbody>
              {preview.rows.map((r, i) => (
                <tr key={i}>
                  <Td className="whitespace-nowrap">{dateFull(r.txn_date)}</Td>
                  <Td className="max-w-[16rem] truncate" title={r.description}>{r.description}</Td>
                  <Td className="text-right"><Amount value={r.amount} currency={currency} />{currency !== "PHP" && <div className="text-xs text-muted">≈ {money(r.amount * r.fx_rate_to_php)}</div>}</Td>
                  <Td><CategorySelect categories={categories} value={r.category_id} onChange={(v) => edit(i, v)} aria-label={`Category for ${r.description}`} /></Td>
                  <Td><SourceBadge source={r.category_source} confidence={r.ai_confidence} /></Td>
                </tr>
              ))}
            </tbody>
          </Table>
          <div className="flex gap-2">
            <Btn onClick={save} disabled={busy}>{busy ? "Importing…" : `Import ${preview.rows.length} transactions`}</Btn>
            <Btn variant="ghost" onClick={() => setPreview(null)}>Back</Btn>
          </div>
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- page
export default function Transactions() {
  const accounts = useApi(() => api("/api/accounts"));
  const cats = useApi(() => api("/api/categories"));
  const [filters, setFilters] = useState({ account_id: "", category_id: "", search: "", date_from: "", date_to: "" });
  const [q, setQ] = useState("");
  const [page, setPage] = useState(0);
  const [tick, setTick] = useState(0);
  const [panel, setPanel] = useState(null);       // 'add' | 'import' | null
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);
  const [busy, setBusy] = useState(false);

  const list = useApi(
    () => api(`/api/transactions${qs({ ...filters, limit: PAGE, offset: page * PAGE })}`),
    [JSON.stringify(filters), page, tick]
  );
  const refresh = () => setTick((t) => t + 1);
  const setFilter = (k, v) => { setFilters((f) => ({ ...f, [k]: v })); setPage(0); };

  const bankAccounts = (accounts.data ?? []).filter((a) => a.is_active && !a.is_investment);
  const categories = cats.data ?? [];
  const total = list.data?.total ?? 0;
  const items = list.data?.items ?? [];

  async function recategorise(id, category_id) {
    setError(null);
    try { await api(`/api/transactions/${id}`, { method: "PUT", body: { category_id } }); refresh(); }
    catch (e) { setError(e.message); }
  }
  async function remove(id) {
    if (!confirm("Delete this transaction?")) return;
    setError(null);
    try { await api(`/api/transactions/${id}`, { method: "DELETE" }); refresh(); } catch (e) { setError(e.message); }
  }
  async function autoCategorise() {
    setBusy(true); setError(null); setNotice(null);
    try {
      const r = await api("/api/transactions/auto-categorize", { method: "POST" });
      setNotice(r.examined === 0 ? "Nothing to categorise: every transaction already has a category."
        : `Looked at ${r.examined} uncategorised transactions and categorised ${r.updated}.${aiNote(r.ai_status)}`);
      refresh();
    } catch (e) { setError(e.message); } finally { setBusy(false); }
  }

  return (
    <Page title="Transactions"
          subtitle="Rows marked Review have no category yet. Auto-categorise uses your keyword rules first, then AI for the rest."
          actions={<>
            <Btn variant="ghost" onClick={autoCategorise} disabled={busy}>{busy ? "Working…" : "Auto-categorise"}</Btn>
            <Btn variant="ghost" onClick={() => setPanel(panel === "import" ? null : "import")}>Import statement</Btn>
            <Btn onClick={() => setPanel(panel === "add" ? null : "add")}>Add transaction</Btn>
          </>}>
      <ErrorMsg error={error || list.error} />
      {notice && <Notice tone="good">{notice}</Notice>}

      {panel === "add" && (
        <Section title="Add a transaction">
          {bankAccounts.length === 0 ? <Empty>Create a bank account first.</Empty> :
            <AddTransaction accounts={bankAccounts} categories={categories} onDone={refresh} setError={setError} setNotice={setNotice} />}
        </Section>
      )}
      {panel === "import" && (
        <Section title="Import a statement" hint="AI categorises each line; you confirm before anything is saved">
          {bankAccounts.length === 0 ? <Empty>Create a bank account first.</Empty> :
            <ImportPanel accounts={bankAccounts} categories={categories} onDone={refresh} setError={setError} setNotice={setNotice} />}
        </Section>
      )}

      <Section title="History" hint={total ? `${total} transaction${total === 1 ? "" : "s"}` : undefined}>
        <form className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5"
              onSubmit={(e) => { e.preventDefault(); setFilter("search", q); }}>
          <Field label="Account"><Select value={filters.account_id} onChange={(e) => setFilter("account_id", e.target.value)}>
            <option value="">All accounts</option>
            {(accounts.data ?? []).map((a) => <option key={a.account_id} value={a.account_id}>{a.name} · {a.currency_code}</option>)}</Select></Field>
          <Field label="Category">
            <CategorySelect categories={categories} value={filters.category_id === "" ? null : Number(filters.category_id)}
                            onChange={(v) => setFilter("category_id", v ?? "")}><option value="">All categories</option></CategorySelect></Field>
          <Field label="From"><Input type="date" value={filters.date_from} onChange={(e) => setFilter("date_from", e.target.value)} /></Field>
          <Field label="To"><Input type="date" value={filters.date_to} onChange={(e) => setFilter("date_to", e.target.value)} /></Field>
          <Field label="Search (press Enter)"><Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="description…" /></Field>
        </form>

        {list.loading && !list.data ? <Loading /> : items.length === 0 ? <Empty>No transactions match.</Empty> : (
          <>
            <Table>
              <thead><tr><Th>Date</Th><Th>Description</Th><Th>Account</Th><Th>Category</Th><Th className="text-right">Amount</Th><Th /><Th /></tr></thead>
              <tbody>
                {items.map((t) => (
                  <tr key={t.id}>
                    <Td className="whitespace-nowrap">{dateFull(t.txn_date)}</Td>
                    <Td className="max-w-[15rem] truncate" title={t.description}>{t.description}</Td>
                    <Td className="whitespace-nowrap text-muted">{t.account_name}</Td>
                    <Td className="min-w-[10rem]">
                      <CategorySelect categories={categories} value={t.category_id} onChange={(v) => v && recategorise(t.id, v)}
                                      aria-label={`Category for ${t.description}`} className="py-1" />
                    </Td>
                    <Td className="whitespace-nowrap text-right">
                      {t.category_kind === "transfer"
                        ? <span className="font-semibold tabular-nums text-muted">{signedMoneyCurrency(t.amount, t.currency_code)}</span>
                        : <Amount value={t.amount} currency={t.currency_code} />}
                      {t.currency_code !== "PHP" && <div className="text-xs text-muted">≈ {money(t.amount_php)}</div>}
                    </Td>
                    <Td><SourceBadge source={t.category_source} confidence={t.ai_confidence} /></Td>
                    <Td><button onClick={() => remove(t.id)} className="text-xs text-muted hover:text-outflow" aria-label={`Delete ${t.description}`}>Delete</button></Td>
                  </tr>
                ))}
              </tbody>
            </Table>
            <div className="mt-3 flex items-center justify-between text-sm text-muted">
              <span>{page * PAGE + 1}–{Math.min((page + 1) * PAGE, total)} of {total}</span>
              <span className="flex gap-2">
                <Btn variant="ghost" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</Btn>
                <Btn variant="ghost" disabled={(page + 1) * PAGE >= total} onClick={() => setPage(page + 1)}>Next</Btn>
              </span>
            </div>
          </>
        )}
      </Section>
    </Page>
  );
}
