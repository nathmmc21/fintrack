import { useState } from "react";
import { api } from "../api";
import { useApi } from "../hooks";
import { dateFull, money, todayISO } from "../format";
import { Amount, Btn, Empty, ErrorMsg, Field, Input, Loading, Notice, Page, Progress, Section, Select, Stats, Table, Td, Th } from "../ui.jsx";

const num = (n, d = 4) => Number(n).toLocaleString(undefined, { maximumFractionDigits: d });

export default function Portfolio() {
  const summary = useApi(() => api("/api/portfolio/summary"));
  const positions = useApi(() => api("/api/portfolio/positions"));
  const trades = useApi(() => api("/api/portfolio/trades"));
  const accounts = useApi(() => api("/api/accounts"));
  const securities = useApi(() => api("/api/securities"));
  const assetClasses = useApi(() => api("/api/asset-classes"));
  const [f, setF] = useState({ account_id: "", security_id: "", trade_type: "buy", quantity: "", price: "", fee: "0", trade_date: todayISO() });
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);

  const reloadAll = () => { summary.reload(); positions.reload(); trades.reload(); };
  const run = async (fn, msg) => {
    setError(null); setNotice(null);
    try { await fn(); if (msg) setNotice(msg); reloadAll(); } catch (e) { setError(e.message); }
  };

  const inv = (accounts.data ?? []).filter((a) => a.is_investment && a.is_active);
  const classNameById = new Map((assetClasses.data ?? []).map((assetClass) => [assetClass.id, assetClass.name]));
  const configuredGroups = [
    { label: "Stocks & funds", classes: ["Stock", "ETF", "Bond Fund"] },
    { label: "Cryptocurrency", classes: ["Crypto"] },
    { label: "Foreign currencies", classes: ["Currency"] },
  ];
  const knownClasses = configuredGroups.flatMap((group) => group.classes);
  const assetGroups = [
    ...configuredGroups,
    ...(assetClasses.data ?? []).filter((assetClass) => !knownClasses.includes(assetClass.name))
      .map((assetClass) => ({ label: assetClass.name, classes: [assetClass.name] })),
  ].map((group) => ({
    ...group,
    assets: (securities.data ?? []).filter((asset) => group.classes.includes(classNameById.get(asset.asset_class_id))),
  })).filter((group) => group.assets.length > 0);
  const s = summary.data;
  const gainPct = s && Number(s.cost_basis) > 0 ? (Number(s.unrealized_gain) / Number(s.cost_basis)) * 100 : 0;

  return (
    <Page title="Portfolio" subtitle="Positions are built from your trades; cost basis uses average buy cost plus fees. Track forex pairs here. For cash held in USD, JPY, or another currency, add a currency account on Accounts. Portfolio prices and totals are in PHP.">
      <ErrorMsg error={error || summary.error || positions.error} />
      {notice && <Notice tone="good">{notice}</Notice>}

      {s && <Stats items={[
        { label: "Market value", value: money(s.market_value) },
        { label: "Cost basis", value: money(s.cost_basis) },
        { label: "Unrealised gain", value: money(s.unrealized_gain), className: Number(s.unrealized_gain) >= 0 ? "text-inflow" : "text-outflow" },
        { label: "Return", value: `${gainPct >= 0 ? "+" : "−"}${Math.abs(gainPct).toFixed(1)}%` },
      ]} />}

      <div className="grid gap-9 md:grid-cols-[1fr_16rem]">
        <Section title="Positions">
          {positions.loading && !positions.data ? <Loading /> : (positions.data ?? []).length === 0 ? <Empty>No holdings yet.</Empty> : (
            <Table>
              <thead><tr><Th>Asset</Th><Th className="text-right">Qty</Th><Th className="text-right">Avg cost</Th><Th className="text-right">Price</Th><Th className="text-right">Value</Th><Th className="text-right">Gain</Th></tr></thead>
              <tbody>
                {positions.data.map((p) => (
                  <tr key={`${p.account_id}-${p.security_id}`}>
                    <Td><span className="font-semibold">{p.symbol}</span><span className="block text-xs text-muted">{p.security_name}</span></Td>
                    <Td className="text-right">{num(p.quantity, 6)}</Td>
                    <Td className="text-right">{money(p.avg_cost)}</Td>
                    <Td className="text-right">{p.latest_price != null ? money(p.latest_price) : <span className="text-muted">n/a</span>}</Td>
                    <Td className="text-right font-semibold">{money(p.market_value)}</Td>
                    <Td className="text-right"><Amount value={p.unrealized_gain} /></Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Section>

        <Section title="Allocation">
          {!s || s.by_asset_class.length === 0 ? <Empty>Nothing to show.</Empty> : (
            <ul className="space-y-3">
              {s.by_asset_class.map((c) => {
                const pct = (Number(c.market_value) / Number(s.market_value)) * 100;
                return (
                  <li key={c.asset_class}>
                    <div className="mb-1 flex justify-between text-sm"><span>{c.asset_class}</span><span className="tabular-nums text-muted">{pct.toFixed(0)}%</span></div>
                    <Progress pct={pct} />
                  </li>
                );
              })}
            </ul>
          )}
        </Section>
      </div>

      <Section title="Record a trade">
        <p className="mb-3 text-xs text-muted">A forex pair here tracks an investment position. Enter the PHP value of one unit; rates are entered manually and do not update automatically.</p>
        {inv.length === 0 ? <Empty>Trades go on an investment account. Add one (type “Brokerage”) on the Accounts page.</Empty> : (
          <form className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4" onSubmit={(e) => {
            e.preventDefault();
            run(async () => {
              await api("/api/portfolio/trades", { method: "POST", body: {
                account_id: Number(f.account_id || inv[0].account_id), security_id: Number(f.security_id),
                trade_type: f.trade_type, quantity: Number(f.quantity), price: Number(f.price), fee: Number(f.fee || 0), trade_date: f.trade_date } });
              setF({ ...f, quantity: "", price: "" });
            }, "Trade recorded.");
          }}>
            <Field label="Account"><Select value={f.account_id || inv[0].account_id} onChange={(e) => setF({ ...f, account_id: e.target.value })}>
              {inv.map((a) => <option key={a.account_id} value={a.account_id}>{a.name}</option>)}</Select></Field>
            <Field label="Asset"><Select required value={f.security_id} onChange={(e) => setF({ ...f, security_id: e.target.value })}>
              <option value="">Choose an asset</option>
              {assetGroups.map((group) => <optgroup key={group.label} label={group.label}>
                {group.assets.map((asset) => <option key={asset.id} value={asset.id}>{asset.symbol} · {asset.name}</option>)}
              </optgroup>)}</Select></Field>
            <div>
              <span className="mb-1 block text-xs font-semibold text-muted">Action</span>
              <div className="flex gap-2">
                <Btn type="button" aria-pressed={f.trade_type === "buy"} variant={f.trade_type === "buy" ? "primary" : "ghost"} className="flex-1" onClick={() => setF({ ...f, trade_type: "buy" })}>Buy</Btn>
                <Btn type="button" aria-pressed={f.trade_type === "sell"} variant={f.trade_type === "sell" ? "primary" : "ghost"} className="flex-1" onClick={() => setF({ ...f, trade_type: "sell" })}>Sell</Btn>
              </div>
            </div>
            <Field label="Date"><Input required type="date" value={f.trade_date} onChange={(e) => setF({ ...f, trade_date: e.target.value })} /></Field>
            <Field label="Quantity"><Input required type="number" min="0.000001" step="any" value={f.quantity} onChange={(e) => setF({ ...f, quantity: e.target.value })} /></Field>
            <Field label="Price per unit (PHP)"><Input required type="number" min="0.0001" step="any" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} /></Field>
            <Field label="Fee"><Input type="number" min="0" step="0.01" value={f.fee} onChange={(e) => setF({ ...f, fee: e.target.value })} /></Field>
            <div className="flex items-end"><Btn type="submit">Record trade</Btn></div>
          </form>
        )}
      </Section>

      <Section title="Trade history">
        {(trades.data ?? []).length === 0 ? <Empty>No trades recorded.</Empty> : (
          <Table>
            <thead><tr><Th>Date</Th><Th>Asset</Th><Th>Action</Th><Th className="text-right">Qty</Th><Th className="text-right">Price</Th><Th className="text-right">Fee</Th><Th /></tr></thead>
            <tbody>
              {trades.data.map((t) => (
                <tr key={t.id}>
                  <Td className="whitespace-nowrap">{dateFull(t.trade_date)}</Td>
                  <Td className="font-semibold">{t.symbol}</Td>
                  <Td><span className={t.trade_type === "buy" ? "text-inflow" : "text-outflow"}>{t.trade_type === "buy" ? "Buy" : "Sell"}</span></Td>
                  <Td className="text-right">{num(t.quantity, 6)}</Td>
                  <Td className="text-right">{money(t.price)}</Td>
                  <Td className="text-right">{money(t.fee)}</Td>
                  <Td><button className="text-xs text-muted hover:text-outflow" onClick={() => confirm("Delete this trade?") && run(() => api(`/api/portfolio/trades/${t.id}`, { method: "DELETE" }))}>Delete</button></Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Section>
    </Page>
  );
}
