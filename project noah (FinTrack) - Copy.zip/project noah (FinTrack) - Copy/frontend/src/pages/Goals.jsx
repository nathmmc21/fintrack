import { useState } from "react";
import { api } from "../api";
import { useApi } from "../hooks";
import { dateFull, money } from "../format";
import { Btn, Empty, ErrorMsg, Field, Input, Loading, Notice, Page, Progress, Section, Select, cx } from "../ui.jsx";

export default function Goals() {
  const goals = useApi(() => api("/api/goals"));
  const accounts = useApi(() => api("/api/accounts"));
  const [form, setForm] = useState({ name: "", target_amount: "", target_date: "" });
  const [contrib, setContrib] = useState({ id: null, amount: "", from: "", fromAmount: "" });
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);

  const run = async (fn, msg) => {
    setError(null); setNotice(null);
    try { await fn(); if (msg) setNotice(msg); goals.reload(); accounts.reload(); } catch (e) { setError(e.message); }
  };
  const bank = (accounts.data ?? []).filter((a) => a.is_active && !a.is_investment);

  return (
    <Page title="Goals" subtitle="Save towards something specific. Add contributions and track what is still needed each month.">
      <ErrorMsg error={error || goals.error} />
      {notice && <Notice tone="good">{notice}</Notice>}

      <Section title="Your goals">
        {goals.loading && !goals.data ? <Loading /> : (goals.data ?? []).length === 0 ? <Empty>No goals yet. Create one below.</Empty> : (
          <ul className="divide-y divide-line rounded-lg border border-line bg-surface">
            {goals.data.map((g) => {
              const source = bank.find((a) => String(a.account_id) === String(contrib.from));
              const sourceCurrency = source?.currency_code ?? "PHP";
              const sourceAmount = sourceCurrency === "PHP" ? Number(contrib.amount) : Number(contrib.fromAmount);
              const rate = sourceCurrency === "PHP" ? 1 : Number(source?.fx_rate_to_php ?? 1);
              const contributionPHP = sourceCurrency === "PHP" ? Number(contrib.amount) : Math.round(sourceAmount * rate * 100) / 100;
              return (
              <li key={g.goal_id} className={cx("px-4 py-4", g.status === "abandoned" && "opacity-60")}>
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <h3 className="font-display text-lg font-semibold">
                    {g.name}
                    {g.status === "achieved" && <span className="ml-2 rounded bg-good-soft px-2 py-0.5 font-sans text-xs font-semibold text-inflow">Achieved</span>}
                    {g.status === "abandoned" && <span className="ml-2 rounded bg-paper px-2 py-0.5 font-sans text-xs font-semibold text-muted">Paused</span>}
                  </h3>
                  <p className="tabular-nums"><span className="font-semibold">{money(g.saved_amount)}</span><span className="text-muted"> of {money(g.target_amount)}</span></p>
                </div>
                <div className="my-2"><Progress pct={Number(g.pct_complete)} tone="bg-inflow" /></div>
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted">
                  <span>
                    {Number(g.pct_complete)}% complete
                    {g.target_date && ` · target ${dateFull(g.target_date)}`}
                    {g.required_monthly != null && ` · ${money(g.required_monthly)} per month needed`}
                  </span>
                  <span className="space-x-3">
                    {g.status === "active" && <button className="font-semibold text-brand" onClick={() => setContrib({ id: contrib.id === g.goal_id ? null : g.goal_id, amount: "", from: "", fromAmount: "" })}>Add money</button>}
                    {g.status !== "achieved" && (
                      <button className="hover:text-brand" onClick={() => run(() => api(`/api/goals/${g.goal_id}`, { method: "PUT", body: { status: g.status === "active" ? "abandoned" : "active" } }))}>
                        {g.status === "active" ? "Pause" : "Resume"}</button>)}
                    <button className="hover:text-outflow" onClick={() => confirm(`Delete goal “${g.name}” and its history?`) && run(() => api(`/api/goals/${g.goal_id}`, { method: "DELETE" }), "Goal deleted.")}>Delete</button>
                  </span>
                </div>

                {contrib.id === g.goal_id && (
                  <form className="mt-3 flex flex-wrap items-end gap-3 rounded-md bg-paper p-3" onSubmit={(e) => {
                    e.preventDefault();
                    run(async () => {
                      const r = await api(`/api/goals/${g.goal_id}/contributions`, { method: "POST",
                        body: {
                          amount: contributionPHP,
                          from_account_id: contrib.from ? Number(contrib.from) : null,
                          from_account_amount: contrib.from && sourceCurrency !== "PHP" ? sourceAmount : (contrib.from ? Number(contrib.amount) : null),
                        } });
                      setContrib({ id: null, amount: "", from: "", fromAmount: "" });
                      setNotice(r.status === "achieved" ? `🎉 “${g.name}” is fully funded!` : "Contribution added.");
                    });
                  }}>
                    {sourceCurrency === "PHP" ? (
                      <Field label="Amount to save (PHP)"><Input autoFocus required type="number" min="0.01" step="0.01" value={contrib.amount} onChange={(e) => setContrib({ ...contrib, amount: e.target.value })} /></Field>
                    ) : (
                      <Field label={`Amount from ${source.name} (${sourceCurrency})`}><Input autoFocus required type="number" min="0.01" step="0.01" value={contrib.fromAmount} onChange={(e) => setContrib({ ...contrib, fromAmount: e.target.value })} /></Field>
                    )}
                    <Field label="Take it from (optional)"><Select value={contrib.from} onChange={(e) => setContrib({ ...contrib, from: e.target.value, amount: "", fromAmount: "" })}>
                      <option value="">Just record it</option>
                      {bank.map((a) => <option key={a.account_id} value={a.account_id}>{a.name} · {a.currency_code}</option>)}</Select></Field>
                    {sourceCurrency !== "PHP" && <p className="self-end pb-2 text-sm text-muted">At {rate} PHP per {sourceCurrency}, about ₱{contributionPHP.toFixed(2)} will be added to the goal.</p>}
                    <Btn type="submit" disabled={sourceCurrency === "PHP" ? Number(contrib.amount) <= 0 : sourceAmount <= 0}>Add</Btn>
                  </form>
                )}
              </li>
            );})}
          </ul>
        )}
      </Section>

      <Section title="New goal">
        <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => {
          e.preventDefault();
          run(async () => {
            await api("/api/goals", { method: "POST", body: { name: form.name, target_amount: Number(form.target_amount), target_date: form.target_date || null } });
            setForm({ name: "", target_amount: "", target_date: "" });
          }, "Goal created.");
        }}>
          <Field label="Name"><Input required maxLength={100} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Emergency fund" /></Field>
          <Field label="Target amount (PHP)"><Input required type="number" min="1" step="0.01" value={form.target_amount} onChange={(e) => setForm({ ...form, target_amount: e.target.value })} /></Field>
          <Field label="Target date (optional)"><Input type="date" value={form.target_date} onChange={(e) => setForm({ ...form, target_date: e.target.value })} /></Field>
          <Btn type="submit">Create goal</Btn>
        </form>
      </Section>
    </Page>
  );
}
