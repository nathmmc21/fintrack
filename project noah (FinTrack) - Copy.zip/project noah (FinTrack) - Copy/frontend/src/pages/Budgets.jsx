import { useState } from "react";
import { api } from "../api";
import { useApi } from "../hooks";
import { money, monthLong } from "../format";
import { Btn, Empty, ErrorMsg, Field, Input, Loading, Notice, Page, Progress, Section, Select, Stats, cx } from "../ui.jsx";

const prevMonth = (ym) => {                       // "2026-10" -> "2026-09-01"
  const [y, m] = ym.split("-").map(Number);
  const d = new Date(y, m - 2, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
};

export default function Budgets() {
  const now = new Date();
  const [ym, setYm] = useState(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`);
  const month = `${ym}-01`;
  const budgets = useApi(() => api(`/api/budgets?month=${month}`), [month]);
  const cats = useApi(() => api("/api/categories"));
  const [add, setAdd] = useState({ category_id: "", limit_amount: "" });
  const [edit, setEdit] = useState({ id: null, value: "" });
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);

  const run = async (fn, msg) => {
    setError(null); setNotice(null);
    try { await fn(); if (msg) setNotice(msg); budgets.reload(); } catch (e) { setError(e.message); }
  };

  const list = budgets.data ?? [];
  const used = new Set(list.map((b) => b.category_id));
  const available = (cats.data ?? []).filter((c) => c.kind === "expense" && !used.has(c.id));
  const totalLimit = list.reduce((s, b) => s + Number(b.limit_amount), 0);
  const totalSpent = list.reduce((s, b) => s + Number(b.spent), 0);

  return (
    <Page title="Budgets" subtitle="Monthly limits per category, compared with what you have actually spent."
          actions={<Field label="Month"><Input type="month" value={ym} onChange={(e) => e.target.value && setYm(e.target.value)} /></Field>}>
      <ErrorMsg error={error || budgets.error} />
      {notice && <Notice tone="good">{notice}</Notice>}

      {list.length > 0 && (
        <Stats items={[
          { label: "Budgeted", value: money(totalLimit) },
          { label: "Spent", value: money(totalSpent), className: totalSpent > totalLimit ? "text-outflow" : undefined },
          { label: totalLimit - totalSpent >= 0 ? "Left" : "Over by", value: money(Math.abs(totalLimit - totalSpent)) },
          { label: "Used", value: `${totalLimit ? Math.round((totalSpent / totalLimit) * 100) : 0}%` },
        ]} />
      )}

      <Section title={monthLong(month)}
               actions={<Btn variant="ghost" className="px-2 py-1 text-xs"
                 onClick={() => run(async () => {
                   const r = await api("/api/budgets/copy", { method: "POST", body: { from_month: prevMonth(ym), to_month: month } });
                   setNotice(`Copied ${r.copied} budget(s) from the previous month.`);
                 })}>Copy from previous month</Btn>}>
        {budgets.loading && !budgets.data ? <Loading /> : list.length === 0 ? <Empty>No budgets for this month yet.</Empty> : (
          <ul className="divide-y divide-line rounded-lg border border-line bg-surface">
            {list.map((b) => {
              const pct = Number(b.pct_used);
              return (
                <li key={b.budget_id} className="px-4 py-3">
                  <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2">
                    <span className="font-semibold">{b.category}</span>
                    <span className="text-sm tabular-nums">
                      <span className={cx("font-semibold", pct >= 100 && "text-outflow")}>{money(b.spent)}</span>
                      <span className="text-muted"> of </span>
                      {edit.id === b.budget_id ? (
                        <>
                          <Input autoFocus type="number" min="1" step="0.01" className="inline-block w-24 py-1" value={edit.value}
                                 onChange={(e) => setEdit({ ...edit, value: e.target.value })} />
                          <Btn className="ml-1 px-2 py-1 text-xs" onClick={() => run(async () => {
                            await api(`/api/budgets/${b.budget_id}`, { method: "PUT", body: { limit_amount: Number(edit.value) } });
                            setEdit({ id: null, value: "" });
                          })}>Save</Btn>
                        </>
                      ) : money(b.limit_amount)}
                    </span>
                  </div>
                  <Progress pct={pct} />
                  <div className="mt-1.5 flex justify-between text-xs text-muted">
                    <span className={cx(pct >= 100 && "font-semibold text-outflow")}>
                      {pct >= 100 ? `Over by ${money(Math.abs(b.remaining))}` : `${money(b.remaining)} left`} · {pct}% used
                    </span>
                    <span className="space-x-3">
                      <button className="hover:text-brand" onClick={() => setEdit({ id: b.budget_id, value: String(b.limit_amount) })}>Edit limit</button>
                      <button className="hover:text-outflow" onClick={() => run(() => api(`/api/budgets/${b.budget_id}`, { method: "DELETE" }))}>Remove</button>
                    </span>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Section>

      <Section title="Add a budget">
        <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => {
          e.preventDefault();
          run(async () => {
            await api("/api/budgets", { method: "POST", body: {
              category_id: Number(add.category_id || available[0].id), budget_month: month, limit_amount: Number(add.limit_amount) } });
            setAdd({ category_id: "", limit_amount: "" });
          });
        }}>
          <Field label="Category"><Select value={add.category_id || available[0]?.id || ""} onChange={(e) => setAdd({ ...add, category_id: e.target.value })}>
            {available.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></Field>
          <Field label="Monthly limit"><Input required type="number" min="1" step="0.01" value={add.limit_amount} onChange={(e) => setAdd({ ...add, limit_amount: e.target.value })} /></Field>
          <Btn type="submit" disabled={available.length === 0}>Add budget</Btn>
        </form>
      </Section>
    </Page>
  );
}
