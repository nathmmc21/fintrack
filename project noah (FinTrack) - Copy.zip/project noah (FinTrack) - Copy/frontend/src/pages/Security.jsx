import { useState } from "react";
import { api } from "../api";
import { useAuth } from "../store.jsx";
import { Btn, ErrorMsg, Field, Input, Notice, Page, Section } from "../ui.jsx";

export default function Security() {
  const { user } = useAuth();
  const [phone, setPhone] = useState(user.phone_number || "");
  const [code, setCode] = useState("");
  const [verificationToken, setVerificationToken] = useState("");
  const [verifiedPhone, setVerifiedPhone] = useState(user.phone_number || "");
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  async function startVerification(e) {
    e.preventDefault();
    setBusy(true); setError(null); setNotice("");
    try {
      const result = await api("/api/auth/phone/request", {
        method: "POST", body: { phone_number: phone },
      });
      setVerificationToken(result.verification_token);
      setNotice(`A verification code was sent to ${phone}. It expires in 10 minutes.`);
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  async function confirmVerification(e) {
    e.preventDefault();
    setBusy(true); setError(null); setNotice("");
    try {
      await api("/api/auth/phone/confirm", {
        method: "POST", body: { verification_token: verificationToken, code },
      });
      setVerificationToken("");
      setCode("");
      setVerifiedPhone(phone);
      setNotice("Your recovery phone number is verified and ready for password resets.");
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  }

  return (
    <Page title="Security" subtitle="Manage the phone number used to recover your account.">
      <Section title="Password recovery">
        <div className="max-w-lg space-y-4">
          <p className="text-sm text-muted">
            Account: <span className="font-medium text-ink">{user.email}</span>
          </p>
          {verifiedPhone && !verificationToken && (
            <Notice tone="good">Verified recovery number: {verifiedPhone}</Notice>
          )}
          {!verificationToken ? (
            <form onSubmit={startVerification} className="space-y-4">
              <Field label="Phone number (include country code)">
                <Input required type="tel" value={phone} onChange={(e) => setPhone(e.target.value)}
                       autoComplete="tel" placeholder="+639171234567" pattern="\+[1-9][0-9]{7,14}" />
              </Field>
              <p className="text-xs text-muted">We’ll text a one-time code to confirm this number. Carrier charges may apply.</p>
              <ErrorMsg error={error} />
              {notice && <Notice tone="good">{notice}</Notice>}
              <Btn type="submit" disabled={busy}>{busy ? "Please wait…" : verifiedPhone ? "Change recovery number" : "Add recovery number"}</Btn>
            </form>
          ) : (
            <form onSubmit={confirmVerification} className="space-y-4">
              <p className="text-sm text-muted">Enter the code sent to {phone}.</p>
              <Field label="Text message code">
                <Input required inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{4,10}"
                       value={code} onChange={(e) => setCode(e.target.value)} />
              </Field>
              <ErrorMsg error={error} />
              {notice && <Notice tone="good">{notice}</Notice>}
              <div className="flex flex-wrap gap-2">
                <Btn type="submit" disabled={busy}>{busy ? "Please wait…" : "Verify phone number"}</Btn>
                <Btn variant="ghost" disabled={busy} onClick={() => { setVerificationToken(""); setNotice(""); setError(null); }}>Use another number</Btn>
              </div>
            </form>
          )}
        </div>
      </Section>
    </Page>
  );
}
