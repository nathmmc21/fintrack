// Small dependency-free SVG bar chart. Each item has one or more bars (e.g. income + expenses).
// A bar can be a forecast (hatched/dashed) and can carry a low/high range drawn as a whisker.
const TONE = { inflow: "var(--color-inflow)", outflow: "var(--color-outflow)", brand: "var(--color-brand)" };

export default function Bars({ items, height = 190, label = "Bar chart", format = (v) => String(v) }) {
  const W = 600, top = 16, bottom = 26, side = 6;
  const max = Math.max(1, ...items.flatMap((i) => i.series.map((s) => s.high ?? s.value)));
  const slot = (W - side * 2) / Math.max(items.length, 1);
  const y = (v) => top + (height - top - bottom) * (1 - v / max);
  const base = y(0);

  return (
    <svg viewBox={`0 0 ${W} ${height}`} className="h-auto w-full" role="img" aria-label={label}>
      <line x1={side} x2={W - side} y1={base} y2={base} stroke="var(--color-line)" />
      {items.map((item, i) => {
        const n = item.series.length;
        const bw = (slot * 0.7) / n;
        const x0 = side + i * slot + (slot - bw * n) / 2;
        return (
          <g key={item.label + i}>
            {item.series.map((s, j) => {
              const x = x0 + j * bw;
              const color = TONE[s.tone] ?? TONE.brand;
              const h = Math.max(base - y(s.value), 0);
              const cx = x + (bw - 2) / 2;
              return (
                <g key={j}>
                  <rect x={x} y={base - h} width={Math.max(bw - 2, 1)} height={h} rx="2" fill={color}
                        fillOpacity={s.forecast ? 0.2 : 1} stroke={s.forecast ? color : "none"}
                        strokeDasharray={s.forecast ? "4 3" : undefined}>
                    <title>{`${item.label}: ${format(s.value)}${s.low != null ? ` (range ${format(s.low)} to ${format(s.high)})` : ""}`}</title>
                  </rect>
                  {s.low != null && (
                    <g stroke={color} strokeWidth="1.5">
                      <line x1={cx} x2={cx} y1={y(s.high)} y2={y(s.low)} />
                      <line x1={cx - 4} x2={cx + 4} y1={y(s.high)} y2={y(s.high)} />
                      <line x1={cx - 4} x2={cx + 4} y1={y(s.low)} y2={y(s.low)} />
                    </g>
                  )}
                  {n === 1 && (
                    <text x={cx} y={y(s.high ?? s.value) - 5} textAnchor="middle" fontSize="10" fill="var(--color-muted)">
                      {format(s.value)}
                    </text>
                  )}
                </g>
              );
            })}
            <text x={side + i * slot + slot / 2} y={height - 8} textAnchor="middle" fontSize="11" fill="var(--color-muted)">
              {item.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
