import { useCallback, useEffect, useState } from "react";

// const { data, error, loading, reload } = useApi(() => api("/api/accounts"), [deps])
export function useApi(fn, deps = []) {
  const [state, setState] = useState({ data: null, error: null, loading: true });
  const run = useCallback(() => {
    setState((s) => ({ ...s, loading: true }));
    return fn().then(
      (data) => setState({ data, error: null, loading: false }),
      (e) => setState({ data: null, error: e.message, loading: false })
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => { run(); }, [run]);
  return { ...state, reload: run };
}
