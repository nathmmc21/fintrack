import { moneyCurrency, signedMoneyCurrency } from "./format";

export const cx = (...c) => c.filter(Boolean).join(" ");

export function Page({ title, subtitle, actions, children }) {
  return (
    <div>
      <header className="mb-7 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">{title}</h1>
          {subtitle && <p className="mt-1 max-w-xl text-sm text-muted">{subtitle}</p>}
        </div>
        {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
      </header>
      <div className="space-y-9">{children}</div>
    </div>
  );
}

// A ruled section instead of a boxed card: keeps numbers and tables the focus.
export function Section({ title, hint, actions, children }) {
  return (
    <section>
      <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-line pb-2">
        <h2 className="font-display text-lg font-semibold">
          {title}
          {hint && <span className="ml-2 font-sans text-sm font-normal text-muted">{hint}</span>}
        </h2>
        {actions && <div className="flex gap-2">{actions}</div>}
      </div>
      <div className="pt-4">{children}</div>
    </section>
  );
}

export function Btn({ variant = "primary", className, ...props }) {
  const styles = {
    primary: "bg-brand text-white hover:bg-[#2233b8]",
    ghost: "border border-line bg-surface text-ink hover:bg-paper",
    danger: "border border-line bg-surface text-outflow hover:bg-bad-soft",
  };
  return (
    <button
      type="button"
      {...props}
      className={cx(
        "inline-flex items-center justify-center gap-1.5 rounded-md px-3.5 py-2 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50",
        styles[variant], className
      )}
    />
  );
}

const inputCls = "w-full rounded-md border border-line bg-surface px-3 py-2 text-sm text-ink placeholder:text-muted/70";
export const Input = ({ className, ...p }) => <input {...p} className={cx(inputCls, className)} />;
export const Select = ({ className, children, ...p }) => <select {...p} className={cx(inputCls, className)}>{children}</select>;
export const Textarea = ({ className, ...p }) => <textarea {...p} className={cx(inputCls, "font-mono text-xs", className)} />;

export function Field({ label, children, className }) {
  return (
    <label className={cx("block", className)}>
      <span className="mb-1 block text-xs font-semibold text-muted">{label}</span>
      {children}
    </label>
  );
}

export const ErrorMsg = ({ error }) =>
  error ? <p role="alert" className="rounded-md bg-bad-soft px-3 py-2 text-sm text-outflow">{error}</p> : null;

export function Notice({ tone = "info", children }) {
  const tones = { info: "bg-brand-soft text-brand", warn: "bg-warn-soft text-warn", good: "bg-good-soft text-inflow" };
  return <p role="status" className={cx("rounded-md px-3 py-2 text-sm", tones[tone])}>{children}</p>;
}

export const Loading = () => <p className="text-sm text-muted">Loading…</p>;
export const Empty = ({ children }) => (
  <p className="rounded-md border border-dashed border-line px-4 py-6 text-center text-sm text-muted">{children}</p>
);

// Money with an explicit sign, so colour is never the only signal.
export function Amount({ value, signed = true, className, currency = "PHP" }) {
  const n = Number(value);
  return (
    <span className={cx("font-semibold tabular-nums", n > 0 && "text-inflow", n < 0 && "text-outflow", className)}>
      {signed ? signedMoneyCurrency(n, currency) : moneyCurrency(n, currency)}
    </span>
  );
}

export function Progress({ pct, tone }) {
  const p = Math.max(0, Math.min(100, Number(pct) || 0));
  const color = tone ?? (pct >= 100 ? "bg-outflow" : pct >= 80 ? "bg-warn" : "bg-brand");
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-line" role="progressbar"
         aria-valuenow={Math.round(p)} aria-valuemin={0} aria-valuemax={100}>
      <div className={cx("h-full rounded-full", color)} style={{ width: `${p}%` }} />
    </div>
  );
}

export function SourceBadge({ source, confidence }) {
  const base = "rounded px-1.5 py-0.5 text-[11px] font-semibold whitespace-nowrap";
  if (source === "ai")
    return <span title="Categorised by AI" className={cx(base, "bg-brand-soft text-brand")}>AI{confidence != null ? ` ${Math.round(confidence * 100)}%` : ""}</span>;
  if (source === "rule") return <span title="Matched a keyword rule" className={cx(base, "bg-good-soft text-inflow")}>Rule</span>;
  if (source === "default") return <span title="Not categorised yet" className={cx(base, "bg-warn-soft text-warn")}>Review</span>;
  return <span className={cx(base, "bg-paper text-muted")}>Manual</span>;
}

// Connected strip of headline numbers (one band, not separate cards).
export function Stats({ items }) {
  return (
    <dl className="grid grid-cols-2 divide-x divide-line overflow-hidden rounded-lg border border-line bg-surface md:grid-cols-4">
      {items.map((s) => (
        <div key={s.label} className="px-4 py-3">
          <dt className="text-xs font-semibold text-muted">{s.label}</dt>
          <dd className={cx("mt-1 font-display text-xl font-bold tabular-nums", s.className)}>{s.value}</dd>
          {s.note && <p className="text-xs text-muted">{s.note}</p>}
        </div>
      ))}
    </dl>
  );
}

export const Table = ({ children }) => (
  <div className="overflow-x-auto rounded-lg border border-line bg-surface">
    <table className="w-full text-left text-sm">{children}</table>
  </div>
);
export const Th = ({ children, className }) => (
  <th className={cx("whitespace-nowrap border-b border-line bg-paper/60 px-3 py-2 text-xs font-semibold text-muted", className)}>{children}</th>
);
export const Td = ({ children, className }) => <td className={cx("border-b border-line/70 px-3 py-2 align-middle", className)}>{children}</td>;
