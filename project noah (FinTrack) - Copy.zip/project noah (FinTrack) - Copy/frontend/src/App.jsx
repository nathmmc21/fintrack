import { NavLink, Navigate, Outlet, Route, Routes, useLocation } from "react-router-dom";
import { useAuth } from "./store.jsx";
import { cx } from "./ui.jsx";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Accounts from "./pages/Accounts.jsx";
import Transactions from "./pages/Transactions.jsx";
import Budgets from "./pages/Budgets.jsx";
import Goals from "./pages/Goals.jsx";
import Portfolio from "./pages/Portfolio.jsx";
import Insights from "./pages/Insights.jsx";
import Admin from "./pages/Admin.jsx";
import Security from "./pages/Security.jsx";

const NAV = [
  { to: "/", label: "Overview", end: true },
  { to: "/accounts", label: "Accounts" },
  { to: "/transactions", label: "Transactions" },
  { to: "/budgets", label: "Budgets" },
  { to: "/goals", label: "Goals" },
  { to: "/portfolio", label: "Portfolio" },
  { to: "/insights", label: "Insights" },
  { to: "/security", label: "Security" },
];

function Shell() {
  const { user, logout } = useAuth();
  const isStaff = ["admin", "staff"].includes(user.role);
  const items = isStaff ? [...NAV, { to: "/admin", label: user.role === "admin" ? "Admin" : "Staff" }] : NAV;

  return (
    <div className="min-h-screen md:flex">
      <aside className="bg-ink text-white md:fixed md:inset-y-0 md:flex md:w-56 md:flex-col">
        <div className="flex items-center justify-between px-5 py-4">
          <span className="font-display text-xl font-bold tracking-tight">FinTrack</span>
          <button onClick={logout} className="text-sm text-white/70 hover:text-white md:hidden">Sign out</button>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-1 md:flex-col md:overflow-visible">
          {items.map((i) => (
            <NavLink key={i.to} to={i.to} end={i.end}
              className={({ isActive }) => cx(
                "whitespace-nowrap rounded-md px-3 py-2 text-sm font-medium transition-colors",
                isActive ? "bg-brand text-white" : "text-white/75 hover:bg-white/10 hover:text-white")}>
              {i.label}
            </NavLink>
          ))}
        </nav>
        <div className="hidden border-t border-white/10 p-4 text-sm md:block">
          <p className="truncate font-semibold">{user.full_name}</p>
          <p className="mb-2 text-xs capitalize text-white/60">{user.role}</p>
          <button onClick={logout} className="text-white/75 hover:text-white">Sign out</button>
        </div>
      </aside>
      <main className="min-w-0 flex-1 p-4 md:ml-56 md:p-9">
        <div className="mx-auto max-w-5xl"><Outlet /></div>
      </main>
    </div>
  );
}

function RequireAuth({ roles }) {
  const { user, ready } = useAuth();
  const location = useLocation();
  if (!ready) return <p className="p-8 text-sm text-muted">Loading…</p>;
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return <Shell />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<RequireAuth />}>
        <Route index element={<Dashboard />} />
        <Route path="/accounts" element={<Accounts />} />
        <Route path="/transactions" element={<Transactions />} />
        <Route path="/budgets" element={<Budgets />} />
        <Route path="/goals" element={<Goals />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/insights" element={<Insights />} />
        <Route path="/security" element={<Security />} />
      </Route>
      <Route element={<RequireAuth roles={["admin", "staff"]} />}>
        <Route path="/admin" element={<Admin />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
