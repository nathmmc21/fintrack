// Same-origin calls work behind Caddy in production and use Vite's /api proxy in local development.
const BASE = import.meta.env.VITE_API_URL ?? "";
const MUTATING_METHODS = new Set(["POST", "PUT", "PATCH", "DELETE"]);
let csrfRequest;

function readCookie(name) {
  const prefix = `${name}=`;
  const item = document.cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith(prefix));
  return item ? decodeURIComponent(item.slice(prefix.length)) : "";
}

async function ensureCsrfToken() {
  let token = readCookie("fintrack_csrf");
  if (token) return token;
  if (!csrfRequest) {
    csrfRequest = fetch(`${BASE}/api/auth/csrf`, { credentials: "same-origin" })
      .then((response) => { if (!response.ok) throw new Error("Could not start a secure session."); })
      .catch(() => { throw new Error("Could not start a secure session. Check that FinTrack is running."); })
      .finally(() => { csrfRequest = null; });
  }
  await csrfRequest;
  token = readCookie("fintrack_csrf");
  if (!token) throw new Error("Could not start a secure session. Refresh the page and try again.");
  return token;
}
export async function api(path, { method = "GET", body, form } = {}) {
  const headers = {};
  if (MUTATING_METHODS.has(method.toUpperCase())) headers["X-CSRF-Token"] = await ensureCsrfToken();

  let payload;
  if (form) payload = new URLSearchParams(form);
  else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }

  let response;
  try {
    response = await fetch(`${BASE}${path}`, {
      method, headers, body: payload, credentials: "same-origin",
    });
  } catch {
    throw new Error("Cannot reach FinTrack. Check that the app services are running.");
  }
  if (response.status === 204) return null;
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    if (response.status === 401 && !path.startsWith("/api/auth/")) window.location.assign("/login");
    const detail = data?.detail;
    throw new Error(Array.isArray(detail) ? detail.map((entry) => entry.msg).join("; ") : detail || response.statusText);
  }
  return data;
}

export const qs = (obj) => {
  const params = new URLSearchParams();
  Object.entries(obj).forEach(([key, value]) => value !== "" && value != null && params.set(key, value));
  const query = params.toString();
  return query ? `?${query}` : "";
};