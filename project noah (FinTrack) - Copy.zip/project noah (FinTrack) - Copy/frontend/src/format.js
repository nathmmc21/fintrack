const locale = import.meta.env.VITE_LOCALE || "en-PH";
const currency = import.meta.env.VITE_CURRENCY || "PHP";
const fmt = new Intl.NumberFormat(locale, { style: "currency", currency });
const fmtCompact = new Intl.NumberFormat(locale, { style: "currency", currency, maximumFractionDigits: 0 });

export const money = (n) => fmt.format(Number(n ?? 0));
export const moneyRound = (n) => fmtCompact.format(Number(n ?? 0));
export const signedMoney = (n) => `${Number(n) > 0 ? "+" : Number(n) < 0 ? "−" : ""}${fmt.format(Math.abs(Number(n ?? 0)))}`;

const currencyFormatters = new Map();
export const moneyCurrency = (n, code = "PHP") => {
  const currencyCode = code || "PHP";
  if (!currencyFormatters.has(currencyCode)) {
    currencyFormatters.set(currencyCode, new Intl.NumberFormat(locale, { style: "currency", currency: currencyCode }));
  }
  const value = Number(n ?? 0);
  const formatter = currencyFormatters.get(currencyCode);
  if (!Number.isInteger(value) && formatter.resolvedOptions().maximumFractionDigits === 0) {
    const fractionalKey = `${currencyCode}:fractional`;
    if (!currencyFormatters.has(fractionalKey)) {
      currencyFormatters.set(fractionalKey, new Intl.NumberFormat(locale, {
        style: "currency", currency: currencyCode, minimumFractionDigits: 0, maximumFractionDigits: 2,
      }));
    }
    return currencyFormatters.get(fractionalKey).format(value);
  }
  return formatter.format(value);
};
export const signedMoneyCurrency = (n, code = "PHP") =>
  `${Number(n) > 0 ? "+" : Number(n) < 0 ? "−" : ""}${moneyCurrency(Math.abs(Number(n ?? 0)), code)}`;

const local = (iso) => new Date(`${String(iso).slice(0, 10)}T00:00:00`);
export const monthShort = (iso) => local(iso).toLocaleDateString(undefined, { month: "short" });
export const monthLong = (iso) => local(iso).toLocaleDateString(undefined, { month: "long", year: "numeric" });
export const dateShort = (iso) => local(iso).toLocaleDateString(undefined, { month: "short", day: "numeric" });
export const dateFull = (iso) => local(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });

export const todayISO = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
export const monthISO = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
