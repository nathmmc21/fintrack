import hashlib
import hmac
import logging
import secrets

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.security import OAuth2PasswordRequestForm

from ..config import settings
from ..db import db
from ..deps import SESSION_COOKIE, current_user
from ..schemas import (PasswordResetSMSConfirmIn, PasswordResetSMSRequestIn,
                       PhoneVerificationConfirmIn, PhoneVerificationStartIn,
                       RegisterStartIn, RegisterVerifyIn)
from ..services import sms as sms_service
from ..security import create_access_token, hash_password, verify_password

router = APIRouter(prefix="/api/auth", tags=["auth"])
CSRF_COOKIE = "fintrack_csrf"
log = logging.getLogger("fintrack.auth")
RESET_REQUEST_MESSAGE = "If an account uses that phone number, a verification code will arrive shortly."

# Hash checked when the email is unknown, so "no such user" and "wrong password" take similar time.
_DUMMY_HASH = hash_password("not-a-real-password")


@router.get("/csrf")
def csrf_token(request: Request, response: Response):
    """Issue the double-submit token used to protect cookie-authenticated writes."""
    token = request.cookies.get(CSRF_COOKIE)
    if not token:
        token = secrets.token_urlsafe(32)
        response.set_cookie(
            CSRF_COOKIE,
            token,
            httponly=False,
            secure=settings.auth_cookie_secure,
            samesite="lax",
            path="/",
            max_age=60 * 60 * 24,
        )
    return {"status": "ok"}

def _fingerprint(purpose: str, value: str) -> str:
    payload = f"{purpose}:{value}".encode("utf-8")
    return hmac.new(settings.jwt_secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()


@router.post("/register")
def start_registration(body: RegisterStartIn):
    """Send one signup code. A customer is not created until the code is approved."""
    if not sms_service.configured():
        raise HTTPException(503, "SMS signup verification is not configured on this server yet.")

    email = str(body.email).lower()
    phone_number = body.phone_number
    phone_fingerprint = _fingerprint("signup-phone", phone_number)
    flow_token = secrets.token_urlsafe(32)
    flow_hash = hashlib.sha256(flow_token.encode("ascii")).hexdigest()

    with db() as cur:
        cur.execute("DELETE FROM pending_registrations WHERE expires_at <= now()")
        cur.execute("DELETE FROM registration_sms_requests WHERE created_at < now() - interval '1 day'")
        cur.execute("SELECT 1 FROM users WHERE email = %s", (email,))
        if cur.fetchone():
            raise HTTPException(409, "An account with that email already exists.")
        cur.execute("SELECT 1 FROM users WHERE phone_number = %s", (phone_number,))
        if cur.fetchone():
            raise HTTPException(409, "That phone number is already linked to an account.")

        cur.execute(
            "SELECT count(*) AS n FROM registration_sms_requests "
            "WHERE phone_fingerprint = %s AND created_at > now() - interval '1 hour'",
            (phone_fingerprint,),
        )
        if cur.fetchone()["n"] >= 3:
            raise HTTPException(429, "Too many signup codes were requested for this number. Try again later.")

        cur.execute(
            "INSERT INTO registration_sms_requests (phone_fingerprint) VALUES (%s)",
            (phone_fingerprint,),
        )
        cur.execute("DELETE FROM pending_registrations WHERE email = %s", (email,))
        cur.execute(
            """INSERT INTO pending_registrations
                 (token_hash, email, phone_number, full_name, password_hash, expires_at)
               VALUES (%s, %s, %s, %s, %s, now() + interval '15 minutes')""",
            (flow_hash, email, phone_number, body.full_name.strip(), hash_password(body.password)),
        )

    try:
        sms_service.send_verification(phone_number)
    except sms_service.SMSProviderError as exc:
        with db() as cur:
            cur.execute("DELETE FROM pending_registrations WHERE token_hash = %s", (flow_hash,))
        log.warning("Signup SMS could not be sent")
        raise HTTPException(502, "Could not send a verification code. Check the number and try again.") from exc

    return {"status": "verification_sent", "registration_token": flow_token}


@router.post("/register/verify", status_code=201)
def finish_registration(body: RegisterVerifyIn):
    flow_hash = hashlib.sha256(body.registration_token.encode("ascii")).hexdigest()
    with db() as cur:
        cur.execute(
            "SELECT email, phone_number FROM pending_registrations "
            "WHERE token_hash = %s AND expires_at > now()",
            (flow_hash,),
        )
        pending = cur.fetchone()
    if not pending:
        raise HTTPException(400, "That signup session expired. Start again to get a new code.")

    try:
        approved = sms_service.check_verification(pending["phone_number"], body.code)
    except sms_service.SMSProviderError as exc:
        log.warning("Signup SMS verification service could not check a code")
        raise HTTPException(502, "SMS verification is temporarily unavailable. Try again shortly.") from exc
    if not approved:
        raise HTTPException(400, "That code is incorrect or expired. Check it and try again.")

    with db() as cur:
        cur.execute(
            "SELECT email, phone_number, full_name, password_hash FROM pending_registrations "
            "WHERE token_hash = %s AND expires_at > now() FOR UPDATE",
            (flow_hash,),
        )
        pending = cur.fetchone()
        if not pending:
            raise HTTPException(400, "That signup session expired. Start again to get a new code.")
        cur.execute(
            """INSERT INTO users (role_id, email, password_hash, full_name, phone_number)
               VALUES ((SELECT id FROM roles WHERE name = 'customer'), %s, %s, %s, %s)
               RETURNING id, email, full_name""",
            (pending["email"], pending["password_hash"], pending["full_name"], pending["phone_number"]),
        )
        created = cur.fetchone()
        cur.execute("DELETE FROM pending_registrations WHERE token_hash = %s", (flow_hash,))
    return created


@router.post("/password-reset/sms/request")
def request_password_reset_sms(body: PasswordResetSMSRequestIn):
    if not sms_service.configured():
        raise HTTPException(503, "SMS password recovery is not configured on this server yet.")

    phone_number = body.phone_number
    phone_fingerprint = _fingerprint("password-reset-phone", phone_number)
    raw_flow_token = secrets.token_urlsafe(32)
    flow_hash = hashlib.sha256(raw_flow_token.encode("ascii")).hexdigest()
    user_id = None
    with db() as cur:
        cur.execute("DELETE FROM sms_password_reset_requests WHERE created_at < now() - interval '1 day'")
        cur.execute(
            "SELECT count(*) AS n FROM sms_password_reset_requests "
            "WHERE phone_fingerprint = %s AND created_at > now() - interval '1 hour'",
            (phone_fingerprint,),
        )
        limited = cur.fetchone()["n"] >= 3
        cur.execute(
            "INSERT INTO sms_password_reset_requests (phone_fingerprint) VALUES (%s)",
            (phone_fingerprint,),
        )
        cur.execute("SELECT id FROM users WHERE phone_number = %s AND is_active = TRUE", (phone_number,))
        user = cur.fetchone()
        if not limited and user:
            user_id = user["id"]
            cur.execute(
                "UPDATE password_reset_tokens SET used_at = now() "
                "WHERE user_id = %s AND used_at IS NULL",
                (user_id,),
            )
            cur.execute(
                "INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) "
                "VALUES (%s, %s, now() + interval '10 minutes')",
                (user_id, flow_hash),
            )

    if user_id is not None and not limited:
        try:
            sms_service.send_verification(phone_number)
        except sms_service.SMSProviderError as exc:
            with db() as cur:
                cur.execute("DELETE FROM password_reset_tokens WHERE token_hash = %s", (flow_hash,))
            log.warning("Password reset SMS could not be sent")
            raise HTTPException(502, "Could not send a verification code. Try again shortly.") from exc
    return {"message": RESET_REQUEST_MESSAGE, "reset_token": raw_flow_token}


@router.post("/password-reset/sms/confirm")
def confirm_password_reset_sms(body: PasswordResetSMSConfirmIn):
    flow_hash = hashlib.sha256(body.reset_token.encode("ascii")).hexdigest()
    with db() as cur:
        cur.execute(
            """SELECT t.user_id, u.phone_number, u.email
               FROM password_reset_tokens t JOIN users u ON u.id = t.user_id
               WHERE t.token_hash = %s AND t.used_at IS NULL AND t.expires_at > now()
                 AND u.is_active = TRUE""",
            (flow_hash,),
        )
        reset = cur.fetchone()
    if not reset:
        raise HTTPException(400, "That code is incorrect or expired. Request a new one.")
    try:
        approved = sms_service.check_verification(reset["phone_number"], body.code)
    except sms_service.SMSProviderError as exc:
        log.warning("Password reset SMS verification service could not check a code")
        raise HTTPException(502, "SMS verification is temporarily unavailable. Try again shortly.") from exc
    if not approved:
        raise HTTPException(400, "That code is incorrect or expired. Request a new one.")

    with db() as cur:
        cur.execute(
            "SELECT user_id FROM password_reset_tokens "
            "WHERE token_hash = %s AND used_at IS NULL AND expires_at > now() FOR UPDATE",
            (flow_hash,),
        )
        token = cur.fetchone()
        if not token:
            raise HTTPException(400, "That code is incorrect or expired. Request a new one.")
        cur.execute(
            "UPDATE users SET password_hash = %s, session_version = session_version + 1 WHERE id = %s",
            (hash_password(body.password), token["user_id"]),
        )
        cur.execute(
            "UPDATE password_reset_tokens SET used_at = now() "
            "WHERE user_id = %s AND used_at IS NULL",
            (token["user_id"],),
        )
    return {"status": "password_reset", "email": reset["email"]}


@router.post("/phone/request")
def request_phone_verification(body: PhoneVerificationStartIn, user: dict = Depends(current_user)):
    if not sms_service.configured():
        raise HTTPException(503, "SMS verification is not configured on this server yet.")
    phone_number = body.phone_number
    phone_fingerprint = _fingerprint("account-phone", phone_number)
    raw_token = secrets.token_urlsafe(32)
    token_hash = hashlib.sha256(raw_token.encode("ascii")).hexdigest()
    with db() as cur:
        cur.execute("SELECT id FROM users WHERE phone_number = %s AND id <> %s", (phone_number, user["id"]))
        if cur.fetchone():
            raise HTTPException(409, "That phone number is already linked to another account.")
        cur.execute("DELETE FROM pending_phone_changes WHERE expires_at <= now()")
        cur.execute("DELETE FROM registration_sms_requests WHERE created_at < now() - interval '1 day'")
        cur.execute(
            "SELECT count(*) AS n FROM registration_sms_requests "
            "WHERE phone_fingerprint = %s AND created_at > now() - interval '1 hour'",
            (phone_fingerprint,),
        )
        if cur.fetchone()["n"] >= 3:
            raise HTTPException(429, "Too many codes were requested for this number. Try again later.")
        cur.execute("INSERT INTO registration_sms_requests (phone_fingerprint) VALUES (%s)", (phone_fingerprint,))
        cur.execute("DELETE FROM pending_phone_changes WHERE user_id = %s", (user["id"],))
        cur.execute(
            """INSERT INTO pending_phone_changes (user_id, token_hash, phone_number, expires_at)
               VALUES (%s, %s, %s, now() + interval '15 minutes')""",
            (user["id"], token_hash, phone_number),
        )
    try:
        sms_service.send_verification(phone_number)
    except sms_service.SMSProviderError as exc:
        with db() as cur:
            cur.execute("DELETE FROM pending_phone_changes WHERE token_hash = %s", (token_hash,))
        log.warning("Account phone verification SMS could not be sent")
        raise HTTPException(502, "Could not send a verification code. Check the number and try again.") from exc
    return {"status": "verification_sent", "verification_token": raw_token}


@router.post("/phone/confirm")
def confirm_phone_verification(body: PhoneVerificationConfirmIn, user: dict = Depends(current_user)):
    token_hash = hashlib.sha256(body.verification_token.encode("ascii")).hexdigest()
    with db() as cur:
        cur.execute(
            """SELECT phone_number FROM pending_phone_changes
               WHERE token_hash = %s AND user_id = %s AND expires_at > now()""",
            (token_hash, user["id"]),
        )
        pending = cur.fetchone()
    if not pending:
        raise HTTPException(400, "That phone verification expired. Request a new code.")
    try:
        approved = sms_service.check_verification(pending["phone_number"], body.code)
    except sms_service.SMSProviderError as exc:
        log.warning("Account phone verification service could not check a code")
        raise HTTPException(502, "SMS verification is temporarily unavailable. Try again shortly.") from exc
    if not approved:
        raise HTTPException(400, "That code is incorrect or expired. Check it and try again.")
    with db() as cur:
        cur.execute(
            """SELECT phone_number FROM pending_phone_changes
               WHERE token_hash = %s AND user_id = %s AND expires_at > now() FOR UPDATE""",
            (token_hash, user["id"]),
        )
        pending = cur.fetchone()
        if not pending:
            raise HTTPException(400, "That phone verification expired. Request a new code.")
        cur.execute("UPDATE users SET phone_number = %s WHERE id = %s", (pending["phone_number"], user["id"]))
        cur.execute("DELETE FROM pending_phone_changes WHERE token_hash = %s", (token_hash,))
    return {"status": "phone_verified"}


@router.post("/login")
def login(response: Response, form: OAuth2PasswordRequestForm = Depends()):
    with db() as cur:
        cur.execute(
            """SELECT u.id, u.password_hash, u.session_version, u.is_active, r.name AS role
               FROM users u JOIN roles r ON r.id = u.role_id WHERE u.email = %s""",
            (form.username.lower(),),
        )
        user = cur.fetchone()
    ok = verify_password(form.password, user["password_hash"] if user else _DUMMY_HASH)
    if not user or not ok or not user["is_active"]:
        raise HTTPException(401, "Incorrect email or password")

    token = create_access_token(user["id"], user["role"], user["session_version"])
    response.set_cookie(
        SESSION_COOKIE, token,
        max_age=settings.jwt_expire_minutes * 60,
        httponly=True,
        secure=settings.auth_cookie_secure,
        samesite="lax",
        path="/",
    )
    return {"status": "authenticated", "role": user["role"]}


@router.post("/logout")
def logout(response: Response):
    response.delete_cookie(
        SESSION_COOKIE, path="/", secure=settings.auth_cookie_secure,
        httponly=True, samesite="lax",
    )
    return {"status": "logged_out"}


@router.get("/me")
def me(user: dict = Depends(current_user)):
    return user
