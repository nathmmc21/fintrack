import hmac
import logging
import asyncio
from contextlib import asynccontextmanager

import psycopg
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from psycopg import errors as pg

from .config import settings
from .db import pool
from .routers import (accounts, admin, auth, budgets, goals, insights, portfolio, reference, transactions)
from .services import ai

log = logging.getLogger("fintrack")


def purge_expired_auth_data():
    with pool.connection() as conn:
        conn.execute("DELETE FROM pending_registrations WHERE expires_at <= now()")
        conn.execute("DELETE FROM pending_phone_changes WHERE expires_at <= now()")
        conn.execute("DELETE FROM registration_sms_requests WHERE created_at < now() - interval '1 day'")
        conn.execute("DELETE FROM sms_password_reset_requests WHERE created_at < now() - interval '1 day'")
        conn.execute("DELETE FROM password_reset_tokens WHERE expires_at < now() - interval '1 day' OR used_at < now() - interval '1 day'")
        conn.execute("DELETE FROM password_reset_requests WHERE created_at < now() - interval '1 day'")


async def auth_data_maintenance():
    while True:
        try:
            await asyncio.to_thread(purge_expired_auth_data)
        except Exception:
            log.exception("Could not clean expired authentication records")
        await asyncio.sleep(15 * 60)


@asynccontextmanager
async def lifespan(app: FastAPI):
    pool.open(wait=True, timeout=15)
    # Idempotent addition for databases created before password recovery existed.
    with pool.connection() as conn:
        conn.execute(
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS session_version INTEGER NOT NULL DEFAULT 0"
        )
        conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS phone_number VARCHAR(16)")
        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_users_phone_number "
            "ON users (phone_number) WHERE phone_number IS NOT NULL"
        )
        conn.execute(
            """CREATE TABLE IF NOT EXISTS password_reset_tokens (
                   id BIGSERIAL PRIMARY KEY,
                   user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                   token_hash CHAR(64) NOT NULL UNIQUE,
                   created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
                   expires_at TIMESTAMPTZ NOT NULL,
                   used_at TIMESTAMPTZ
               )"""
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS ix_password_reset_tokens_user_created "
            "ON password_reset_tokens (user_id, created_at DESC)"
        )
        conn.execute(
            """CREATE TABLE IF NOT EXISTS password_reset_requests (
                   email_fingerprint CHAR(64) NOT NULL,
                   created_at TIMESTAMPTZ NOT NULL DEFAULT now()
               )"""
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS ix_password_reset_requests_fingerprint_created "
            "ON password_reset_requests (email_fingerprint, created_at DESC)"
        )
        conn.execute(
            """CREATE TABLE IF NOT EXISTS pending_registrations (
                   id BIGSERIAL PRIMARY KEY,
                   token_hash CHAR(64) NOT NULL UNIQUE,
                   email VARCHAR(255) NOT NULL,
                   phone_number VARCHAR(16) NOT NULL,
                   full_name VARCHAR(120) NOT NULL,
                   password_hash TEXT NOT NULL,
                   created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
                   expires_at TIMESTAMPTZ NOT NULL
               )"""
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS ix_pending_registrations_email "
            "ON pending_registrations (email, created_at DESC)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS ix_pending_registrations_expiry "
            "ON pending_registrations (expires_at)"
        )
        conn.execute(
            """CREATE TABLE IF NOT EXISTS registration_sms_requests (
                   phone_fingerprint CHAR(64) NOT NULL,
                   created_at TIMESTAMPTZ NOT NULL DEFAULT now()
               )"""
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS ix_registration_sms_requests_phone_created "
            "ON registration_sms_requests (phone_fingerprint, created_at DESC)"
        )
        conn.execute(
            """CREATE TABLE IF NOT EXISTS sms_password_reset_requests (
                   phone_fingerprint CHAR(64) NOT NULL,
                   created_at TIMESTAMPTZ NOT NULL DEFAULT now()
               )"""
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS ix_sms_password_reset_requests_phone_created "
            "ON sms_password_reset_requests (phone_fingerprint, created_at DESC)"
        )
        conn.execute(
            """CREATE TABLE IF NOT EXISTS pending_phone_changes (
                   id BIGSERIAL PRIMARY KEY,
                   user_id INT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
                   token_hash CHAR(64) NOT NULL UNIQUE,
                   phone_number VARCHAR(16) NOT NULL,
                   created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
                   expires_at TIMESTAMPTZ NOT NULL
               )"""
        )
    maintenance_task = asyncio.create_task(auth_data_maintenance())
    try:
        yield
    finally:
        maintenance_task.cancel()
        await asyncio.gather(maintenance_task, return_exceptions=True)
        pool.close()


app = FastAPI(title="FinTrack API", version="1.1.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in settings.cors_origins.split(",") if origin.strip()],
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
    allow_headers=["Authorization", "Content-Type", "X-CSRF-Token"],
)


@app.middleware("http")
async def csrf_protection(request: Request, call_next):
    if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
        cookie_token = request.cookies.get("fintrack_csrf", "")
        header_token = request.headers.get("X-CSRF-Token", "")
        if not cookie_token or not header_token or not hmac.compare_digest(cookie_token, header_token):
            return JSONResponse({"detail": "CSRF check failed. Refresh the page and try again."}, status_code=403)
    return await call_next(request)


for router in (auth.router, admin.users_router, admin.admin_router,
               reference.institutions, reference.account_types, reference.asset_classes,
               reference.securities, reference.prices, reference.categories, reference.rules,
               accounts.router, transactions.router, budgets.router, goals.router,
               portfolio.router, insights.router):
    app.include_router(router)


@app.get("/api/health", tags=["meta"])
def health():
    return {"status": "ok"}


@app.exception_handler(psycopg.Error)
async def database_error(request: Request, exc: psycopg.Error):
    """Turn database constraint errors into clean 4xx responses; never leak SQL details."""
    if isinstance(exc, (pg.RaiseException, pg.InvalidParameterValue)):
        return JSONResponse({"detail": exc.diag.message_primary}, status_code=400)
    if isinstance(exc, pg.UniqueViolation):
        if exc.diag.constraint_name == "uq_accounts_user_institution_type_name":
            return JSONResponse({"detail": "That account name and type already exist at this institution"}, status_code=409)
        if exc.diag.constraint_name == "uq_accounts_user_last4":
            return JSONResponse({"detail": "Those last four digits are already used on another account"}, status_code=409)
        return JSONResponse({"detail": "That already exists"}, status_code=409)
    if isinstance(exc, pg.ForeignKeyViolation):
        return JSONResponse({"detail": "Conflicts with related data (it is still in use, or a referenced item does not exist)"}, status_code=409)
    if isinstance(exc, (pg.CheckViolation, pg.NotNullViolation, pg.InvalidTextRepresentation,
                        pg.NumericValueOutOfRange, pg.StringDataRightTruncation, pg.InvalidDatetimeFormat)):
        return JSONResponse({"detail": "Invalid value"}, status_code=400)
    log.exception("Unhandled database error")
    return JSONResponse({"detail": "Database error"}, status_code=500)


@app.exception_handler(ai.AIUnavailable)
async def ai_unavailable(request: Request, exc: ai.AIUnavailable):
    return JSONResponse({"detail": str(exc)}, status_code=503)


@app.exception_handler(ai.AIProviderError)
async def ai_provider_error(request: Request, exc: ai.AIProviderError):
    log.warning("Local AI service failed: %s", exc)
    return JSONResponse({"detail": "The local AI service failed. Try again shortly."}, status_code=502)


@app.exception_handler(ai.AIBadResponse)
async def ai_bad_response(request: Request, exc: ai.AIBadResponse):
    return JSONResponse({"detail": "The AI returned something unusable. Please try again."}, status_code=502)
