import base64
import json
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

from ..config import settings


class SMSProviderError(Exception):
    pass


def configured() -> bool:
    return all((settings.twilio_api_key, settings.twilio_api_secret,
                settings.twilio_verify_service_sid))


def _post(resource: str, fields: dict[str, str]) -> dict:
    if not configured():
        raise SMSProviderError("SMS verification is not configured")
    service = quote(settings.twilio_verify_service_sid, safe="")
    url = f"https://verify.twilio.com/v2/Services/{service}/{resource}"
    credentials = base64.b64encode(
        f"{settings.twilio_api_key}:{settings.twilio_api_secret}".encode("utf-8")
    ).decode("ascii")
    request = Request(
        url,
        data=urlencode(fields).encode("ascii"),
        headers={
            "Authorization": f"Basic {credentials}",
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=10) as response:
            return json.loads(response.read())
    except (HTTPError, URLError, TimeoutError, OSError, ValueError) as exc:
        # Never include the provider response, number, or credentials in user-facing errors.
        raise SMSProviderError("The SMS verification service could not complete the request") from exc


def send_verification(phone_number: str) -> None:
    result = _post("Verifications", {"To": phone_number, "Channel": "sms"})
    if result.get("status") != "pending":
        raise SMSProviderError("The SMS verification service did not start a verification")


def check_verification(phone_number: str, code: str) -> bool:
    result = _post("VerificationCheck", {"To": phone_number, "Code": code})
    return result.get("status") == "approved"
