import smtplib
import ssl
from email.message import EmailMessage

from ..config import settings


def password_reset_email(recipient: str, reset_url: str) -> None:
    """Send a short-lived password reset link using the configured SMTP server."""
    if not (settings.smtp_host and settings.smtp_from_email):
        raise RuntimeError("Password recovery email is not configured")
    if bool(settings.smtp_user) != bool(settings.smtp_password):
        raise RuntimeError("SMTP_USER and SMTP_PASSWORD must be configured together")

    message = EmailMessage()
    message["Subject"] = "Reset your FinTrack password"
    message["From"] = settings.smtp_from_email
    message["To"] = recipient
    message.set_content(
        "We received a request to reset your FinTrack password.\n\n"
        f"Use this link within 30 minutes:\n{reset_url}\n\n"
        "If you did not request this, you can ignore this message. Your password has not changed."
    )

    context = ssl.create_default_context()
    if settings.smtp_use_ssl:
        with smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port, timeout=10, context=context) as server:
            if settings.smtp_user:
                server.login(settings.smtp_user, settings.smtp_password)
            server.send_message(message)
        return

    with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=10) as server:
        server.ehlo()
        if settings.smtp_use_starttls:
            server.starttls(context=context)
            server.ehlo()
        if settings.smtp_user:
            server.login(settings.smtp_user, settings.smtp_password)
        server.send_message(message)
