$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$certificatePath = Join-Path $env:TEMP "fintrack-caddy-local-root.crt"
Push-Location $projectRoot
try {
    try { Invoke-WebRequest -Uri https://localhost/api/health -SkipCertificateCheck -TimeoutSec 10 | Out-Null } catch { }
    docker compose cp web:/data/caddy/pki/authorities/local/root.crt $certificatePath
    if ($LASTEXITCODE -ne 0) { throw "Could not copy Caddy's local root certificate. Start the stack first." }

    $certificate = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($certificatePath)
    $storePath = "Cert:\CurrentUser\Root\$($certificate.Thumbprint)"
    if (Test-Path -LiteralPath $storePath) {
        Write-Host "FinTrack's local HTTPS certificate is already trusted for this Windows user."
    } else {
        Import-Certificate -FilePath $certificatePath -CertStoreLocation Cert:\CurrentUser\Root | Out-Null
        Write-Host "Trusted Caddy's local certificate for this Windows user. Reopen https://localhost."
    }
} finally {
    Pop-Location
}