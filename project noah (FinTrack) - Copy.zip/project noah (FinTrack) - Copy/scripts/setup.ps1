$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$examplePath = Join-Path $projectRoot ".env.example"
$envPath = Join-Path $projectRoot ".env"
if (Test-Path -LiteralPath $envPath) { Write-Host ".env already exists; leaving your settings unchanged."; exit 0 }
if (-not (Test-Path -LiteralPath $examplePath -PathType Leaf)) { throw "Missing environment template: $examplePath" }

function New-UrlSafeSecret([int]$ByteCount) {
    $bytes = [byte[]]::new($ByteCount)
    $generator = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $generator.GetBytes($bytes) } finally { $generator.Dispose() }
    return [Convert]::ToBase64String($bytes).TrimEnd([char]"=").Replace("+", "-").Replace("/", "_")
}

$content = Get-Content -LiteralPath $examplePath -Raw
$content = $content.Replace("POSTGRES_PASSWORD=replace-with-a-long-random-password", "POSTGRES_PASSWORD=$(New-UrlSafeSecret 32)")
$content = $content.Replace("JWT_SECRET=replace-with-a-random-secret-at-least-32-characters-long", "JWT_SECRET=$(New-UrlSafeSecret 48)")
[System.IO.File]::WriteAllText($envPath, $content, [System.Text.UTF8Encoding]::new($false))
Write-Host "Created .env with generated secrets. It is ignored by Git; keep it private."