-- Optional demo data for local development only.
-- Creates well-known accounts (including admin@fintrack.test / Admin123!).
-- Never load this file into a publicly accessible deployment.
INSERT INTO users (role_id, email, password_hash, full_name)
SELECT r.id, v.email, crypt(v.pw, gen_salt('bf', 12)), v.full_name
FROM (VALUES
    ('admin',    'admin@fintrack.test', 'Admin123!',    'Ada Admin'),
    ('staff',    'staff@fintrack.test', 'Staff123!',    'Sid Staff'),
    ('customer', 'demo@fintrack.test',  'Customer123!', 'Dana Demo'),
    ('customer', 'sam@fintrack.test',   'Customer123!', 'Sam Sample')
) AS v(role, email, pw, full_name)
JOIN roles r ON r.name = v.role;

-- ---------- Accounts ----------
INSERT INTO accounts (user_id, institution_id, account_type_id, name, last4, opening_balance)
SELECT u.id, i.id, t.id, v.name, v.last4, v.opening
FROM (VALUES
    ('demo@fintrack.test', 'Northwind Bank',      'Checking',    'Everyday Checking',   '4821', 2500.00),
    ('demo@fintrack.test', 'Harbor Credit Union', 'Savings',     'High-Yield Savings',  '9937', 8000.00),
    ('demo@fintrack.test', 'Northwind Bank',      'Credit Card', 'Rewards Credit Card', '1156',    0.00),
    ('demo@fintrack.test', 'Summit Brokerage',    'Brokerage',   'Summit Brokerage',    '7702',    0.00),
    ('sam@fintrack.test',  'Northwind Bank',      'Checking',    'Sam Checking',        '3340', 1200.00)
) AS v(email, inst, typ, name, last4, opening)
JOIN users u ON u.email = v.email
JOIN institutions i ON i.name = v.inst
JOIN account_types t ON t.name = v.typ;

-- ---------- Six months of history for the demo user (drives the forecast) ----------
-- Deterministic "noise" via modulo so every install gets the same numbers.
WITH acct AS (
    SELECT a.id, a.name FROM accounts a JOIN users u ON u.id = a.user_id WHERE u.email = 'demo@fintrack.test'
),
months AS (
    SELECT m, (date_trunc('month', current_date) - make_interval(months => m))::date AS first_day
    FROM generate_series(0, 5) AS m
),
gen(acct_name, cat_name, txn_date, descr, amt, src) AS (
    SELECT 'Everyday Checking', 'Salary', first_day, 'ACME CORP PAYROLL', 3200.00, 'rule' FROM months
    UNION ALL
    SELECT 'Everyday Checking', 'Rent & Housing', first_day + 2, 'RENT PAYMENT OAKVIEW APTS', -1100.00, 'rule' FROM months
    UNION ALL
    SELECT 'Everyday Checking', 'Utilities', first_day + 9, 'CITY ELECTRIC CO', -(75 + (m * 11) % 25)::numeric, 'rule' FROM months
    UNION ALL
    SELECT 'Everyday Checking', 'Groceries', first_day + 3 + w * 7, 'FRESHMART GROCERY #' || (100 + w),
           -(52 + (5 - m) * 6 + (w * 7 + m * 3) % 13)::numeric, 'rule'
    FROM months, generate_series(0, 3) AS w
    UNION ALL
    SELECT 'Everyday Checking', 'Dining', first_day + 1 + j * 6,
           (ARRAY['STARBUCKS #1042', 'MCDONALD''S 5521', 'CHIPOTLE 0831', 'LOCAL CAFE', 'DOMINOS PIZZA'])[1 + j],
           -(12 + (j * 7 + m * 5) % 19)::numeric, 'rule'
    FROM months, generate_series(0, 4) AS j
    UNION ALL
    SELECT 'Everyday Checking', 'Transport', first_day + 4 + j * 7,
           CASE WHEN j % 2 = 0 THEN 'UBER TRIP' ELSE 'SHELL FUEL' END,
           -(18 + (j * 5 + m * 3) % 14)::numeric, 'rule'
    FROM months, generate_series(0, 3) AS j
    UNION ALL
    SELECT 'Everyday Checking', 'Health', first_day + 16, 'CITY PHARMACY', -(22 + m * 4)::numeric, 'rule'
    FROM months WHERE m % 2 = 0
    UNION ALL
    SELECT 'Rewards Credit Card', 'Subscriptions', first_day + 11, 'NETFLIX.COM', -15.99, 'rule' FROM months
    UNION ALL
    SELECT 'Rewards Credit Card', 'Subscriptions', first_day + 11, 'SPOTIFY USA', -9.99, 'rule' FROM months
    UNION ALL
    SELECT 'Rewards Credit Card', 'Shopping', first_day + 14 + k * 7, 'AMAZON MKTPLACE',
           -(25 + (k * 31 + m * 17) % 90)::numeric, 'rule'
    FROM months, generate_series(0, 1) AS k
    UNION ALL
    SELECT 'Rewards Credit Card', 'Entertainment', first_day + 19, 'CINEPLEX TICKETS',
           -(18 + (m * 7) % 13)::numeric, 'manual' FROM months
    UNION ALL
    SELECT 'High-Yield Savings', 'Interest & Dividends', first_day + 27, 'INTEREST PAYMENT',
           (3.5 + m * 0.1)::numeric, 'rule' FROM months
)
INSERT INTO transactions (account_id, category_id, txn_date, description, amount, category_source)
SELECT a.id, c.id, g.txn_date, g.descr, g.amt, g.src
FROM gen g
JOIN acct a ON a.name = g.acct_name
JOIN categories c ON c.user_id IS NULL AND c.name = g.cat_name
WHERE g.txn_date <= current_date;

-- Raw, uncategorised rows: try "Auto-categorise" on the Transactions page.
-- category_id is NULL on purpose -> trigger trg_txn_validate assigns 'Uncategorized'.
INSERT INTO transactions (account_id, category_id, txn_date, description, amount, category_source)
SELECT (SELECT a.id FROM accounts a JOIN users u ON u.id = a.user_id
         WHERE u.email = 'demo@fintrack.test' AND a.name = 'Everyday Checking'),
       NULL::int, v.d, v.descr, v.amt, 'default'
FROM (VALUES
    (current_date - 1, 'POS 88231 K DELI #22',          -14.75),
    (current_date - 2, 'DR LIM DENTAL ASSOC',           -85.00),
    (current_date - 3, 'CITYBUS TRANSIT MONTHLY PASS',  -40.00),
    (current_date - 4, 'PAYPAL *FREELANCE INV 2210',   450.00)
) AS v(d, descr, amt);

-- Sam: just enough to prove users cannot see each other's data.
INSERT INTO transactions (account_id, category_id, txn_date, description, amount, category_source)
SELECT a.id, c.id, current_date - v.days, v.descr, v.amt, 'manual'
FROM (VALUES (2, 'Groceries', 'FRESHMART GROCERY #9', -61.20), (5, 'Salary', 'ACME CORP PAYROLL', 2100.00)) AS v(days, cat, descr, amt)
JOIN accounts a ON a.name = 'Sam Checking'
JOIN categories c ON c.user_id IS NULL AND c.name = v.cat;

-- ---------- Budgets (this month and last month) ----------
INSERT INTO budgets (user_id, category_id, budget_month, limit_amount)
SELECT u.id, c.id, (date_trunc('month', current_date) - make_interval(months => m))::date, v.lim
FROM (VALUES ('Groceries', 300), ('Dining', 110), ('Transport', 110), ('Shopping', 120),
             ('Entertainment', 30), ('Subscriptions', 30), ('Utilities', 110)) AS v(cat, lim)
JOIN categories c ON c.user_id IS NULL AND c.name = v.cat
CROSS JOIN generate_series(0, 1) AS m
JOIN users u ON u.email = 'demo@fintrack.test';

-- ---------- Goals (the third one is fully funded -> trigger marks it 'achieved') ----------
INSERT INTO goals (user_id, account_id, name, target_amount, target_date)
SELECT u.id, a.id, v.name, v.target, current_date + v.days
FROM users u
JOIN accounts a ON a.user_id = u.id AND a.name = 'High-Yield Savings'
CROSS JOIN (VALUES ('Emergency fund', 10000, 300), ('Japan trip', 2500, 180), ('New headphones', 200, 30)) AS v(name, target, days)
WHERE u.email = 'demo@fintrack.test';

INSERT INTO goal_contributions (goal_id, amount, contributed_on, note)
SELECT g.id, v.amount, current_date - v.days_ago, v.note
FROM (VALUES
    ('Emergency fund', 500, 150, 'Monthly saving'), ('Emergency fund', 500, 120, 'Monthly saving'),
    ('Emergency fund', 500,  90, 'Monthly saving'), ('Emergency fund', 600,  60, 'Bonus top-up'),
    ('Emergency fund', 500,  30, 'Monthly saving'),
    ('Japan trip',     400,  75, 'Saved from freelance'), ('Japan trip', 350, 20, 'Monthly saving'),
    ('New headphones', 120,  40, 'First half'), ('New headphones', 80, 10, 'Second half')
) AS v(goal, amount, days_ago, note)
JOIN goals g ON g.name = v.goal
JOIN users u ON u.id = g.user_id AND u.email = 'demo@fintrack.test'
ORDER BY v.days_ago DESC;

INSERT INTO investment_trades (account_id, security_id, trade_type, quantity, price, fee, trade_date)
SELECT a.id, s.id, t.trade_type, t.qty, t.price, t.fee, current_date - t.days_ago
FROM (VALUES
    ('NWX',  'buy',  12, 94.50, 1.00, 150),
    ('NWX',  'buy',   8, 98.20, 1.00,  60),
    ('HBR',  'buy',  25, 49.10, 1.00, 120),
    ('SUMT', 'buy',   6, 171.00, 1.00, 90),
    ('SUMT', 'sell',  2, 184.00, 1.00, 20)
) AS t(symbol, trade_type, qty, price, fee, days_ago)
JOIN securities s ON s.symbol = t.symbol
JOIN accounts a ON a.name = 'Summit Brokerage'
JOIN users u ON u.id = a.user_id AND u.email = 'demo@fintrack.test'
ORDER BY t.days_ago DESC;
