-- Reference data only: safe to load in a personal or public deployment.

INSERT INTO roles (name) VALUES ('admin'), ('staff'), ('customer');

INSERT INTO institutions (name) VALUES
    ('BDO Unibank'),
    ('Bank of the Philippine Islands (BPI)'),
    ('Metrobank'),
    ('Land Bank of the Philippines (LANDBANK)'),
    ('Philippine National Bank (PNB)'),
    ('Security Bank'),
    ('UnionBank'),
    ('Rizal Commercial Banking Corporation (RCBC)'),
    ('China Banking Corporation (Chinabank)'),
    ('EastWest Bank'),
    ('Philippine Savings Bank (PSBank)'),
    ('GoTyme Bank'),
    ('Maya Bank'),
    ('Tonik Digital Bank'),
    ('UnionDigital Bank'),
    ('UNObank'),
    ('Overseas Filipino Bank'),
    ('Other Philippine Bank');

INSERT INTO account_types (name, is_investment) VALUES
    ('Checking', FALSE), ('Savings', FALSE), ('Credit Card', FALSE), ('Cash', FALSE), ('Brokerage', TRUE);

INSERT INTO asset_classes (name) VALUES ('Stock'), ('ETF'), ('Bond Fund'), ('Crypto'), ('Currency');

INSERT INTO categories (user_id, name, kind) VALUES
    (NULL, 'Groceries', 'expense'),      (NULL, 'Dining', 'expense'),
    (NULL, 'Transport', 'expense'),      (NULL, 'Utilities', 'expense'),
    (NULL, 'Rent & Housing', 'expense'), (NULL, 'Health', 'expense'),
    (NULL, 'Entertainment', 'expense'),  (NULL, 'Shopping', 'expense'),
    (NULL, 'Subscriptions', 'expense'),  (NULL, 'Education', 'expense'),
    (NULL, 'Travel', 'expense'),         (NULL, 'Insurance', 'expense'),
    (NULL, 'Uncategorized', 'expense'),
    (NULL, 'Salary', 'income'),          (NULL, 'Freelance', 'income'),
    (NULL, 'Interest & Dividends', 'income'), (NULL, 'Other Income', 'income'),
    (NULL, 'Transfer', 'transfer');

INSERT INTO category_rules (user_id, keyword, category_id)
SELECT NULL::int, v.kw, c.id
FROM (VALUES
    ('starbucks','Dining'), ('mcdonald','Dining'), ('chipotle','Dining'), ('dominos','Dining'), ('cafe','Dining'),
    ('freshmart','Groceries'), ('grocery','Groceries'), ('supermarket','Groceries'),
    ('uber','Transport'), ('lyft','Transport'), ('shell','Transport'), ('fuel','Transport'),
    ('netflix','Subscriptions'), ('spotify','Subscriptions'),
    ('electric','Utilities'), ('water bill','Utilities'), ('internet','Utilities'),
    ('rent','Rent & Housing'), ('pharmacy','Health'),
    ('amazon','Shopping'), ('payroll','Salary'), ('salary','Salary'), ('interest','Interest & Dividends')
) AS v(kw, cat)
JOIN categories c ON c.user_id IS NULL AND c.name = v.cat;

-- ---------- Securities, price history, trades ----------
INSERT INTO securities (symbol, name, asset_class_id)
SELECT v.symbol, v.name, ac.id
FROM (VALUES
    ('NWX',  'Northwind Global Equity ETF', 'ETF'),
    ('HBR',  'Harbor Aggregate Bond Fund',  'Bond Fund'),
    ('SUMT', 'Summit Technologies',         'Stock'),
    ('ORBE', 'Orbit Energy Corp',           'Stock'),
    ('BTC',  'Bitcoin',                     'Crypto'),
    ('ETH',  'Ethereum',                    'Crypto'),
    ('SOL',  'Solana',                      'Crypto'),
    ('XRP',  'XRP',                          'Crypto'),
    ('USD/PHP', 'US Dollar ',   'Currency'),
    ('JPY/PHP', 'Japanese Yen ', 'Currency'),
    ('EUR/PHP', 'Euro ',        'Currency'),
    ('GBP/PHP', 'British Pound ', 'Currency'),
    ('SGD/PHP', 'Singapore Dollar ', 'Currency'),
    ('AUD/PHP', 'Australian Dollar ', 'Currency'),
    ('CAD/PHP', 'Canadian Dollar ', 'Currency'),
    ('CHF/PHP', 'Swiss Franc ', 'Currency'),
    ('CNY/PHP', 'Chinese Yuan ', 'Currency'),
    ('HKD/PHP', 'Hong Kong Dollar ', 'Currency'),
    ('NZD/PHP', 'New Zealand Dollar ', 'Currency'),
    ('SEK/PHP', 'Swedish Krona ', 'Currency'),
    ('NOK/PHP', 'Norwegian Krone ', 'Currency'),
    ('DKK/PHP', 'Danish Krone ', 'Currency'),
    ('ZAR/PHP', 'South African Rand ', 'Currency')
) AS v(symbol, name, cls)
JOIN asset_classes ac ON ac.name = v.cls;

-- Fictional tickers and prices: for demonstration only.
INSERT INTO security_prices (security_id, price_date, close_price)
SELECT s.id, current_date - (m * 30),
       ROUND((p.base * (1 + (5 - m) * 0.012 + ((m * 7 + s.id) % 5 - 2) * 0.006))::numeric, 4)
FROM securities s
JOIN (VALUES ('NWX', 100.0), ('HBR', 50.0), ('SUMT', 180.0), ('ORBE', 40.0)) AS p(symbol, base) ON p.symbol = s.symbol
CROSS JOIN generate_series(0, 5) AS m;

