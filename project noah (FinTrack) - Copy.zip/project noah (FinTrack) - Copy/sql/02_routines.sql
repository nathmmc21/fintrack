-- =====================================================================
-- VIEWS (6)
-- =====================================================================

-- 1) Current balance per account (opening balance + all transactions).
CREATE VIEW v_account_balances AS
SELECT a.id AS account_id, a.user_id, a.name, a.last4, a.is_active, a.opening_balance,
       i.name AS institution, t.name AS account_type, t.is_investment,
       a.institution_id, a.account_type_id,
       COALESCE(SUM(tx.amount), 0)::NUMERIC(14,2)                      AS txn_total,
       (a.opening_balance + COALESCE(SUM(tx.amount), 0))::NUMERIC(14,2) AS current_balance
FROM accounts a
JOIN institutions  i ON i.id = a.institution_id
JOIN account_types t ON t.id = a.account_type_id
LEFT JOIN transactions tx ON tx.account_id = a.id
GROUP BY a.id, i.name, t.name, t.is_investment;

-- 2) Money in / out per user, month and category (transfers excluded).
--    Expenses are reported as positive "spend"; refunds reduce it.
CREATE VIEW v_monthly_category_spend AS
SELECT a.user_id,
       date_trunc('month', tx.txn_date)::date AS month,
       c.id AS category_id, c.name AS category, c.kind,
       (CASE WHEN c.kind = 'expense' THEN -SUM(tx.amount) ELSE SUM(tx.amount) END)::NUMERIC(14,2) AS total,
       COUNT(*) AS txn_count
FROM transactions tx
JOIN accounts   a ON a.id = tx.account_id
JOIN categories c ON c.id = tx.category_id
WHERE c.kind IN ('income', 'expense')
GROUP BY a.user_id, date_trunc('month', tx.txn_date), c.id, c.name, c.kind;

-- 3) Budget vs. actual (joins view 2).
CREATE VIEW v_budget_status AS
SELECT b.id AS budget_id, b.user_id, b.category_id, c.name AS category, b.budget_month, b.limit_amount,
       COALESCE(s.total, 0)                                               AS spent,
       b.limit_amount - COALESCE(s.total, 0)                              AS remaining,
       ROUND(100 * COALESCE(s.total, 0) / b.limit_amount, 1)              AS pct_used
FROM budgets b
JOIN categories c ON c.id = b.category_id
LEFT JOIN v_monthly_category_spend s
       ON s.user_id = b.user_id AND s.category_id = b.category_id AND s.month = b.budget_month;

-- 4) Goal progress and the monthly saving rate still needed to hit the target date.
CREATE VIEW v_goal_progress AS
WITH s AS (
    SELECT g.id AS goal_id, g.user_id, g.account_id, g.name, g.target_amount, g.target_date, g.status,
           COALESCE(SUM(gc.amount), 0)::NUMERIC(12,2) AS saved_amount
    FROM goals g
    LEFT JOIN goal_contributions gc ON gc.goal_id = g.id
    GROUP BY g.id
)
SELECT s.*,
       LEAST(100, ROUND(100 * s.saved_amount / s.target_amount, 1)) AS pct_complete,
       CASE WHEN s.target_date IS NOT NULL AND s.status = 'active'
            THEN ROUND(GREATEST(s.target_amount - s.saved_amount, 0)
                       / GREATEST(1, CEIL((s.target_date - CURRENT_DATE) / 30.44)), 2)
       END AS required_monthly
FROM s;

-- 5) Open positions: quantity, average cost, latest price, market value, unrealised gain.
CREATE VIEW v_portfolio_positions AS
WITH pos AS (
    SELECT a.user_id, t.account_id, a.name AS account_name,
           s.id AS security_id, s.symbol, s.name AS security_name, ac.name AS asset_class,
           SUM(CASE WHEN t.trade_type = 'buy' THEN t.quantity ELSE -t.quantity END) AS quantity,
           SUM(CASE WHEN t.trade_type = 'buy' THEN t.quantity * t.price + t.fee ELSE 0 END)
             / NULLIF(SUM(CASE WHEN t.trade_type = 'buy' THEN t.quantity ELSE 0 END), 0) AS avg_cost
    FROM investment_trades t
    JOIN accounts      a  ON a.id  = t.account_id
    JOIN securities    s  ON s.id  = t.security_id
    JOIN asset_classes ac ON ac.id = s.asset_class_id
    GROUP BY a.user_id, t.account_id, a.name, s.id, s.symbol, s.name, ac.name
    HAVING SUM(CASE WHEN t.trade_type = 'buy' THEN t.quantity ELSE -t.quantity END) > 0
)
SELECT pos.user_id, pos.account_id, pos.account_name, pos.security_id, pos.symbol, pos.security_name,
       pos.asset_class, pos.quantity,
       ROUND(pos.avg_cost, 4)                                              AS avg_cost,
       ROUND(pos.quantity * pos.avg_cost, 2)                               AS cost_basis,
       lp.close_price                                                      AS latest_price,
       ROUND(pos.quantity * COALESCE(lp.close_price, pos.avg_cost), 2)     AS market_value,
       ROUND(pos.quantity * (COALESCE(lp.close_price, pos.avg_cost) - pos.avg_cost), 2) AS unrealized_gain
FROM pos
LEFT JOIN LATERAL (
    SELECT sp.close_price FROM security_prices sp
    WHERE sp.security_id = pos.security_id
    ORDER BY sp.price_date DESC LIMIT 1
) lp ON TRUE;

-- 6) Net worth parts per user (uses scalar subqueries over views 1 and 5).
CREATE VIEW v_net_worth AS
SELECT u.id AS user_id,
       COALESCE((SELECT SUM(b.current_balance) FROM v_account_balances b
                 WHERE b.user_id = u.id AND NOT b.is_investment AND b.is_active), 0)::NUMERIC(14,2) AS bank_total,
       COALESCE((SELECT SUM(p.market_value) FROM v_portfolio_positions p
                 WHERE p.user_id = u.id), 0)::NUMERIC(14,2) AS portfolio_value
FROM users u;


-- =====================================================================
-- TRIGGER FUNCTIONS + TRIGGERS (4)
-- =====================================================================

-- T1: every transaction gets a category, and the category must be a system one or the owner's own.
CREATE FUNCTION fn_txn_validate() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    v_owner     INT;
    v_cat_owner INT;
BEGIN
    SELECT user_id INTO v_owner FROM accounts WHERE id = NEW.account_id;

    IF NEW.category_id IS NULL THEN
        SELECT id INTO NEW.category_id FROM categories
         WHERE user_id IS NULL
           AND name = CASE WHEN NEW.amount > 0 THEN 'Other Income' ELSE 'Uncategorized' END;
        NEW.category_source := 'default';
        NEW.ai_confidence   := NULL;
    ELSE
        SELECT user_id INTO v_cat_owner FROM categories WHERE id = NEW.category_id;
        IF FOUND AND v_cat_owner IS NOT NULL AND v_cat_owner <> v_owner THEN
            RAISE EXCEPTION 'Category does not belong to this user' USING ERRCODE = '22023';
        END IF;
    END IF;
    RETURN NEW;
END $$;

CREATE TRIGGER trg_txn_validate
    BEFORE INSERT OR UPDATE ON transactions
    FOR EACH ROW EXECUTE FUNCTION fn_txn_validate();

-- T2: a goal flips to 'achieved' as soon as contributions reach the target.
CREATE FUNCTION fn_goal_status() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    UPDATE goals g SET status = 'achieved'
     WHERE g.id = NEW.goal_id
       AND g.status = 'active'
       AND (SELECT COALESCE(SUM(amount), 0) FROM goal_contributions WHERE goal_id = g.id) >= g.target_amount;
    RETURN NULL;
END $$;

CREATE TRIGGER trg_goal_status
    AFTER INSERT ON goal_contributions
    FOR EACH ROW EXECUTE FUNCTION fn_goal_status();

-- T3: trades only on investment accounts, and never sell more than is held.
CREATE FUNCTION fn_trade_check() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    v_is_inv BOOLEAN;
    v_held   NUMERIC;
BEGIN
    SELECT t.is_investment INTO v_is_inv
      FROM accounts a JOIN account_types t ON t.id = a.account_type_id
     WHERE a.id = NEW.account_id;
    IF NOT COALESCE(v_is_inv, FALSE) THEN
        RAISE EXCEPTION 'Trades can only be recorded on investment accounts' USING ERRCODE = '22023';
    END IF;

    IF NEW.trade_type = 'sell' THEN
        SELECT COALESCE(SUM(CASE WHEN trade_type = 'buy' THEN quantity ELSE -quantity END), 0)
          INTO v_held
          FROM investment_trades
         WHERE account_id = NEW.account_id AND security_id = NEW.security_id;
        IF NEW.quantity > v_held THEN
            RAISE EXCEPTION 'Cannot sell % units; only % held', NEW.quantity, v_held USING ERRCODE = '22023';
        END IF;
    END IF;
    RETURN NEW;
END $$;

CREATE TRIGGER trg_trade_check
    BEFORE INSERT ON investment_trades
    FOR EACH ROW EXECUTE FUNCTION fn_trade_check();

-- T4: security-relevant user changes (role / activation) are written to audit_log.
CREATE FUNCTION fn_users_audit() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO audit_log (table_name, record_id, action, old_data, new_data)
    VALUES ('users', NEW.id, 'UPDATE',
            jsonb_build_object('role_id', OLD.role_id, 'is_active', OLD.is_active),
            jsonb_build_object('role_id', NEW.role_id, 'is_active', NEW.is_active));
    RETURN NEW;
END $$;

CREATE TRIGGER trg_users_audit
    AFTER UPDATE ON users
    FOR EACH ROW
    WHEN (OLD.role_id IS DISTINCT FROM NEW.role_id OR OLD.is_active IS DISTINCT FROM NEW.is_active)
    EXECUTE FUNCTION fn_users_audit();


-- =====================================================================
-- STORED PROCEDURES (4)  -- called from the API with CALL ...
-- =====================================================================

-- P1: bulk-insert transactions (used by statement import). Returns the number inserted.
--     Values arrive as JSON text and are cast here, so the API never builds SQL strings.
CREATE PROCEDURE sp_import_transactions(
    p_user_id    INT,
    p_account_id INT,
    p_rows       JSONB,
    INOUT p_inserted INT DEFAULT 0)
LANGUAGE plpgsql AS $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM accounts WHERE id = p_account_id AND user_id = p_user_id AND is_active) THEN
        RAISE EXCEPTION 'Account not found or inactive' USING ERRCODE = '22023';
    END IF;
    IF jsonb_typeof(p_rows) <> 'array' OR jsonb_array_length(p_rows) = 0 THEN
        RAISE EXCEPTION 'Nothing to import' USING ERRCODE = '22023';
    END IF;

    INSERT INTO transactions (account_id, category_id, txn_date, description, amount, category_source, ai_confidence)
    SELECT p_account_id, r.category_id, r.txn_date::DATE, left(r.description, 255), r.amount::NUMERIC,
           COALESCE(r.category_source, 'default'), r.ai_confidence::NUMERIC
    FROM jsonb_to_recordset(p_rows)
         AS r(category_id INT, txn_date TEXT, description TEXT, amount TEXT, category_source TEXT, ai_confidence TEXT);

    GET DIAGNOSTICS p_inserted = ROW_COUNT;
END $$;

-- P2: move money between two of the user's accounts as a pair of 'Transfer' transactions.
CREATE PROCEDURE sp_transfer_funds(
    p_user_id INT, p_from_account INT, p_to_account INT,
    p_amount NUMERIC, p_date DATE, p_note TEXT)
LANGUAGE plpgsql AS $$
DECLARE
    v_cat  INT;
    v_from TEXT;
    v_to   TEXT;
    v_tail TEXT;
BEGIN
    IF p_amount IS NULL OR p_amount <= 0 THEN
        RAISE EXCEPTION 'Transfer amount must be positive' USING ERRCODE = '22023';
    END IF;
    IF p_from_account = p_to_account THEN
        RAISE EXCEPTION 'Choose two different accounts' USING ERRCODE = '22023';
    END IF;

    SELECT name INTO v_from FROM accounts WHERE id = p_from_account AND user_id = p_user_id AND is_active;
    SELECT name INTO v_to   FROM accounts WHERE id = p_to_account   AND user_id = p_user_id AND is_active;
    IF v_from IS NULL OR v_to IS NULL THEN
        RAISE EXCEPTION 'Both accounts must be your active accounts' USING ERRCODE = '22023';
    END IF;

    SELECT id INTO v_cat FROM categories WHERE user_id IS NULL AND name = 'Transfer';
    v_tail := COALESCE(' - ' || NULLIF(p_note, ''), '');

    INSERT INTO transactions (account_id, category_id, txn_date, description, amount, category_source) VALUES
        (p_from_account, v_cat, COALESCE(p_date, CURRENT_DATE), left('Transfer to '   || v_to   || v_tail, 255), -p_amount, 'default'),
        (p_to_account,   v_cat, COALESCE(p_date, CURRENT_DATE), left('Transfer from ' || v_from || v_tail, 255),  p_amount, 'default');
END $$;

-- P3: add a contribution to a goal; optionally debit it from one of the user's accounts.
CREATE PROCEDURE sp_contribute_to_goal(
    p_user_id INT, p_goal_id INT, p_amount NUMERIC, p_from_account INT, p_note TEXT)
LANGUAGE plpgsql AS $$
DECLARE
    v_name   TEXT;
    v_status TEXT;
    v_cat    INT;
BEGIN
    IF p_amount IS NULL OR p_amount <= 0 THEN
        RAISE EXCEPTION 'Contribution must be positive' USING ERRCODE = '22023';
    END IF;

    SELECT name, status INTO v_name, v_status
      FROM goals WHERE id = p_goal_id AND user_id = p_user_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Goal not found' USING ERRCODE = '22023';
    END IF;
    IF v_status <> 'active' THEN
        RAISE EXCEPTION 'This goal is already %', v_status USING ERRCODE = '22023';
    END IF;

    IF p_from_account IS NOT NULL THEN
        IF NOT EXISTS (SELECT 1 FROM accounts WHERE id = p_from_account AND user_id = p_user_id AND is_active) THEN
            RAISE EXCEPTION 'Source account not found' USING ERRCODE = '22023';
        END IF;
        SELECT id INTO v_cat FROM categories WHERE user_id IS NULL AND name = 'Transfer';
        INSERT INTO transactions (account_id, category_id, txn_date, description, amount, category_source)
        VALUES (p_from_account, v_cat, CURRENT_DATE, left('Goal: ' || v_name, 255), -p_amount, 'default');
    END IF;

    INSERT INTO goal_contributions (goal_id, amount, note) VALUES (p_goal_id, p_amount, p_note);
END $$;

-- P4: copy one month's budgets into another month (existing rows are kept). Returns rows copied.
CREATE PROCEDURE sp_copy_budgets(
    p_user_id INT, p_from_month DATE, p_to_month DATE,
    INOUT p_copied INT DEFAULT 0)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO budgets (user_id, category_id, budget_month, limit_amount)
    SELECT user_id, category_id, date_trunc('month', p_to_month)::date, limit_amount
      FROM budgets
     WHERE user_id = p_user_id
       AND budget_month = date_trunc('month', p_from_month)::date
    ON CONFLICT (user_id, category_id, budget_month) DO NOTHING;

    GET DIAGNOSTICS p_copied = ROW_COUNT;
END $$;
