-- Keep historical account links intact while replacing the fictional institution choices.
ALTER TABLE institutions
    ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE;

UPDATE institutions
SET is_active = FALSE
WHERE name IN ('Northwind Bank', 'Harbor Credit Union', 'Summit Brokerage', 'Pocket Cash');

INSERT INTO institutions (name, is_active) VALUES
    ('BDO Unibank', TRUE),
    ('Bank of the Philippine Islands (BPI)', TRUE),
    ('Metrobank', TRUE),
    ('Land Bank of the Philippines (LANDBANK)', TRUE),
    ('Philippine National Bank (PNB)', TRUE),
    ('Security Bank', TRUE),
    ('UnionBank', TRUE),
    ('Rizal Commercial Banking Corporation (RCBC)', TRUE),
    ('China Banking Corporation (Chinabank)', TRUE),
    ('EastWest Bank', TRUE),
    ('Philippine Savings Bank (PSBank)', TRUE),
    ('GoTyme Bank', TRUE),
    ('Maya Bank', TRUE),
    ('Tonik Digital Bank', TRUE),
    ('UnionDigital Bank', TRUE),
    ('UNObank', TRUE),
    ('Overseas Filipino Bank', TRUE),
    ('Other Philippine Bank', TRUE)
ON CONFLICT (name) DO UPDATE SET is_active = EXCLUDED.is_active;
