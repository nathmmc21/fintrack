-- Prevent one user from reusing the same last four digits on another account.
-- Existing duplicate labels are preserved; this trigger blocks new or changed duplicates.
BEGIN;

CREATE OR REPLACE FUNCTION fn_prevent_duplicate_account_last4()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF NEW.last4 IS NULL THEN
        RETURN NEW;
    END IF;

    -- Serialize account-number checks per user so concurrent inserts cannot race.
    PERFORM 1 FROM users WHERE id = NEW.user_id FOR UPDATE;

    IF EXISTS (
        SELECT 1
          FROM accounts a
         WHERE a.user_id = NEW.user_id
           AND a.last4 = NEW.last4
           AND a.id IS DISTINCT FROM NEW.id
    ) THEN
        RAISE EXCEPTION 'Those last four digits are already used on another account'
            USING ERRCODE = '23505', CONSTRAINT = 'uq_accounts_user_last4';
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_accounts_unique_last4_insert ON accounts;
CREATE TRIGGER trg_accounts_unique_last4_insert
    BEFORE INSERT ON accounts
    FOR EACH ROW
    EXECUTE FUNCTION fn_prevent_duplicate_account_last4();

DROP TRIGGER IF EXISTS trg_accounts_unique_last4_update ON accounts;
CREATE TRIGGER trg_accounts_unique_last4_update
    BEFORE UPDATE OF user_id, last4 ON accounts
    FOR EACH ROW
    EXECUTE FUNCTION fn_prevent_duplicate_account_last4();

COMMIT;
