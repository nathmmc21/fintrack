-- Allow the same display name across different account types, such as Cash and Brokerage.
-- Keep names unique within a type for each user. Safe for existing databases and reruns.
BEGIN;

ALTER TABLE accounts
    DROP CONSTRAINT IF EXISTS accounts_user_id_name_key;

CREATE UNIQUE INDEX IF NOT EXISTS uq_accounts_user_type_name
    ON accounts (user_id, account_type_id, name);

COMMIT;
