-- Add foreign currency holdings quoted in PHP for the Portfolio tracker.
-- Exchange rates are manually entered as the PHP value of one unit of foreign currency.
BEGIN;

INSERT INTO asset_classes (name)
VALUES ('Currency')
ON CONFLICT (name) DO NOTHING;

INSERT INTO securities (symbol, name, asset_class_id)
SELECT v.symbol, v.name, ac.id
FROM (VALUES
    ('USD', 'US Dollar '),
    ('JPY', 'Japanese Yen '),
    ('EURP', 'Euro '),
    ('GBP', 'British Pound '),
    ('SGD', 'Singapore Dollar '),
    ('AUD', 'Australian Dollar '),
    ('CAD', 'Canadian Dollar '),
    ('CHF', 'Swiss Franc '),
    ('CNY', 'Chinese Yuan '),
    ('HKD', 'Hong Kong Dollar '),
    ('NZD', 'New Zealand Dollar '),
    ('SEK', 'Swedish Krona '),
    ('NOK', 'Norwegian Krone '),
    ('DKK', 'Danish Krone '),
    ('INR', 'Indian Rupee '),
    ('BRL', 'Brazilian Real '),
    ('MXN', 'Mexican Peso '),
    ('ZAR', 'South African Rand ')
) AS v(symbol, name)
JOIN asset_classes ac ON ac.name = 'Currency'
ON CONFLICT (symbol) DO NOTHING;

COMMIT;
