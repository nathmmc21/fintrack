-- Add native-currency cash accounts while keeping all budgets and reports in PHP.
-- Rates are entered by the user; no external exchange-rate service is used.
BEGIN;

ALTER TABLE accounts
    ADD COLUMN IF NOT EXISTS currency_code VARCHAR(3) NOT NULL DEFAULT 'PHP',
    ADD COLUMN IF NOT EXISTS fx_rate_to_php NUMERIC(18,8) NOT NULL DEFAULT 1;

ALTER TABLE transactions
    ADD COLUMN IF NOT EXISTS fx_rate_to_php NUMERIC(18,8) NOT NULL DEFAULT 1;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_accounts_currency_code') THEN
        ALTER TABLE accounts ADD CONSTRAINT ck_accounts_currency_code
            CHECK (currency_code ~ '^[A-Z]{3}$');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_accounts_fx_rate_positive') THEN
        ALTER TABLE accounts ADD CONSTRAINT ck_accounts_fx_rate_positive
            CHECK (fx_rate_to_php > 0);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_accounts_php_rate_is_one') THEN
        ALTER TABLE accounts ADD CONSTRAINT ck_accounts_php_rate_is_one
            CHECK (currency_code <> 'PHP' OR fx_rate_to_php = 1);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_transactions_fx_rate_positive') THEN
        ALTER TABLE transactions ADD CONSTRAINT ck_transactions_fx_rate_positive
            CHECK (fx_rate_to_php > 0);
    END IF;
END $$;

CREATE OR REPLACE VIEW v_account_balances AS
SELECT a.id AS account_id, a.user_id, a.name, a.last4, a.is_active, a.opening_balance,
       i.name AS institution, t.name AS account_type, t.is_investment,
       a.institution_id, a.account_type_id,
       COALESCE(SUM(tx.amount), 0)::NUMERIC(14,2) AS txn_total,
       (a.opening_balance + COALESCE(SUM(tx.amount), 0))::NUMERIC(14,2) AS current_balance,
       a.currency_code, a.fx_rate_to_php,
       ROUND((a.opening_balance + COALESCE(SUM(tx.amount), 0)) * a.fx_rate_to_php, 2)::NUMERIC(14,2)
           AS current_balance_php
FROM accounts a
JOIN institutions i ON i.id = a.institution_id
JOIN account_types t ON t.id = a.account_type_id
LEFT JOIN transactions tx ON tx.account_id = a.id
GROUP BY a.id, i.name, t.name, t.is_investment;

CREATE OR REPLACE VIEW v_monthly_category_spend AS
SELECT a.user_id,
       date_trunc('month', tx.txn_date)::date AS month,
       c.id AS category_id, c.name AS category, c.kind,
       ROUND(CASE WHEN c.kind = 'expense' THEN -SUM(tx.amount * tx.fx_rate_to_php)
                  ELSE SUM(tx.amount * tx.fx_rate_to_php) END, 2)::NUMERIC(14,2) AS total,
       COUNT(*) AS txn_count
FROM transactions tx
JOIN accounts a ON a.id = tx.account_id
JOIN categories c ON c.id = tx.category_id
WHERE c.kind IN ('income', 'expense')
GROUP BY a.user_id, date_trunc('month', tx.txn_date), c.id, c.name, c.kind;

CREATE OR REPLACE VIEW v_net_worth AS
SELECT u.id AS user_id,
       COALESCE((SELECT SUM(b.current_balance_php) FROM v_account_balances b
                 WHERE b.user_id = u.id AND NOT b.is_investment AND b.is_active), 0)::NUMERIC(14,2) AS bank_total,
       COALESCE((SELECT SUM(p.market_value) FROM v_portfolio_positions p
                 WHERE p.user_id = u.id), 0)::NUMERIC(14,2) AS portfolio_value
FROM users u;

CREATE OR REPLACE PROCEDURE sp_import_transactions(
    p_user_id INT,
    p_account_id INT,
    p_rows JSONB,
    INOUT p_inserted INT DEFAULT 0)
LANGUAGE plpgsql AS $$
DECLARE
    v_account_rate NUMERIC(18,8);
BEGIN
    SELECT fx_rate_to_php INTO v_account_rate
      FROM accounts WHERE id = p_account_id AND user_id = p_user_id AND is_active;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Account not found or inactive' USING ERRCODE = '22023';
    END IF;
    IF jsonb_typeof(p_rows) <> 'array' OR jsonb_array_length(p_rows) = 0 THEN
        RAISE EXCEPTION 'Nothing to import' USING ERRCODE = '22023';
    END IF;

    INSERT INTO transactions (account_id, category_id, txn_date, description, amount,
                             category_source, ai_confidence, fx_rate_to_php)
    SELECT p_account_id, r.category_id, r.txn_date::DATE, left(r.description, 255), r.amount::NUMERIC,
           COALESCE(r.category_source, 'default'), r.ai_confidence::NUMERIC,
           COALESCE(NULLIF(r.fx_rate_to_php, '')::NUMERIC, v_account_rate)
    FROM jsonb_to_recordset(p_rows)
         AS r(category_id INT, txn_date TEXT, description TEXT, amount TEXT,
              category_source TEXT, ai_confidence TEXT, fx_rate_to_php TEXT);

    GET DIAGNOSTICS p_inserted = ROW_COUNT;
END $$;

DROP PROCEDURE IF EXISTS sp_transfer_funds(INT, INT, INT, NUMERIC, DATE, TEXT);
DROP PROCEDURE IF EXISTS sp_transfer_funds(INT, INT, INT, NUMERIC, NUMERIC, DATE, TEXT);
CREATE PROCEDURE sp_transfer_funds(
    p_user_id INT, p_from_account INT, p_to_account INT,
    p_from_amount NUMERIC, p_to_amount NUMERIC, p_date DATE, p_note TEXT)
LANGUAGE plpgsql AS $$
DECLARE
    v_cat INT;
    v_from TEXT;
    v_to TEXT;
    v_from_currency TEXT;
    v_to_currency TEXT;
    v_from_rate NUMERIC(18,8);
    v_to_rate NUMERIC(18,8);
    v_tail TEXT;
BEGIN
    IF p_from_amount IS NULL OR p_from_amount <= 0 OR p_to_amount IS NULL OR p_to_amount <= 0 THEN
        RAISE EXCEPTION 'Transfer amounts must be positive' USING ERRCODE = '22023';
    END IF;
    IF p_from_account = p_to_account THEN
        RAISE EXCEPTION 'Choose two different accounts' USING ERRCODE = '22023';
    END IF;

    SELECT name, currency_code, fx_rate_to_php
      INTO v_from, v_from_currency, v_from_rate
      FROM accounts WHERE id = p_from_account AND user_id = p_user_id AND is_active;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Both accounts must be your active accounts' USING ERRCODE = '22023';
    END IF;
    SELECT name, currency_code, fx_rate_to_php
      INTO v_to, v_to_currency, v_to_rate
      FROM accounts WHERE id = p_to_account AND user_id = p_user_id AND is_active;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Both accounts must be your active accounts' USING ERRCODE = '22023';
    END IF;
    IF v_from_currency = v_to_currency AND p_from_amount <> p_to_amount THEN
        RAISE EXCEPTION 'Transfers between accounts using the same currency must use the same amount' USING ERRCODE = '22023';
    END IF;

    SELECT id INTO v_cat FROM categories WHERE user_id IS NULL AND name = 'Transfer';
    v_tail := COALESCE(' - ' || NULLIF(p_note, ''), '');

    INSERT INTO transactions (account_id, category_id, txn_date, description, amount, category_source, fx_rate_to_php) VALUES
        (p_from_account, v_cat, COALESCE(p_date, CURRENT_DATE), left('Transfer to ' || v_to || v_tail, 255), -p_from_amount, 'default', v_from_rate),
        (p_to_account, v_cat, COALESCE(p_date, CURRENT_DATE), left('Transfer from ' || v_from || v_tail, 255), p_to_amount, 'default', v_to_rate);
END $$;

DROP PROCEDURE IF EXISTS sp_contribute_to_goal(INT, INT, NUMERIC, INT, TEXT);
DROP PROCEDURE IF EXISTS sp_contribute_to_goal(INT, INT, NUMERIC, INT, NUMERIC, TEXT);
CREATE PROCEDURE sp_contribute_to_goal(
    p_user_id INT, p_goal_id INT, p_amount NUMERIC, p_from_account INT,
    p_from_account_amount NUMERIC, p_note TEXT)
LANGUAGE plpgsql AS $$
DECLARE
    v_cat INT;
    v_name TEXT;
    v_account_name TEXT;
    v_currency TEXT;
    v_rate NUMERIC(18,8);
BEGIN
    IF p_amount IS NULL OR p_amount <= 0 THEN
        RAISE EXCEPTION 'Contribution must be positive' USING ERRCODE = '22023';
    END IF;
    SELECT name INTO v_name FROM goals WHERE id = p_goal_id AND user_id = p_user_id AND status = 'active';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Goal not found or not active' USING ERRCODE = '22023';
    END IF;

    IF p_from_account IS NOT NULL THEN
        SELECT name, currency_code, fx_rate_to_php
          INTO v_account_name, v_currency, v_rate
          FROM accounts WHERE id = p_from_account AND user_id = p_user_id AND is_active;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Source account not found or inactive' USING ERRCODE = '22023';
        END IF;
        IF p_from_account_amount IS NULL THEN
            IF v_currency <> 'PHP' THEN
                RAISE EXCEPTION 'Enter the amount to deduct from the foreign-currency account' USING ERRCODE = '22023';
            END IF;
            p_from_account_amount := p_amount;
        END IF;
        IF p_from_account_amount <= 0 OR ROUND(p_from_account_amount * v_rate, 2) <> ROUND(p_amount, 2) THEN
            RAISE EXCEPTION 'The PHP contribution must match the source amount and its saved exchange rate' USING ERRCODE = '22023';
        END IF;
        SELECT id INTO v_cat FROM categories WHERE user_id IS NULL AND name = 'Transfer';
        INSERT INTO transactions (account_id, category_id, txn_date, description, amount, category_source, fx_rate_to_php)
        VALUES (p_from_account, v_cat, CURRENT_DATE, left('Goal: ' || v_name, 255),
                -p_from_account_amount, 'default', v_rate);
    ELSIF p_from_account_amount IS NOT NULL THEN
        RAISE EXCEPTION 'Choose a source account for the account amount' USING ERRCODE = '22023';
    END IF;

    INSERT INTO goal_contributions (goal_id, amount, note) VALUES (p_goal_id, p_amount, p_note);
END $$;

COMMIT;
