-- Allow the same account name at different institutions, while preventing a duplicate
-- for the same user, institution, and account type. Existing accounts are preserved.
BEGIN;

ALTER TABLE accounts
    DROP CONSTRAINT IF EXISTS accounts_user_id_name_key;

DROP INDEX IF EXISTS uq_accounts_user_type_name;

CREATE UNIQUE INDEX IF NOT EXISTS uq_accounts_user_institution_type_name
    ON accounts (user_id, institution_id, account_type_id, name);

COMMIT;
