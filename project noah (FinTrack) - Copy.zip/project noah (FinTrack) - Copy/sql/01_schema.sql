-- FinTrack: Financial Portfolio & Budget Tracker
-- PostgreSQL 14+.  Runs automatically via docker-entrypoint-initdb.d (files run in name order).
--
-- 3NF notes
--   * Balances, goal progress, order-style totals and portfolio values are NOT stored; they are
--     derived in views (see 02_routines.sql), so no column depends on another non-key column.
--   * Lookup data (roles, account_types, institutions, asset_classes) lives in its own tables.

CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- used by the seed script to create bcrypt hashes

-- ===================== Identity & access =====================
CREATE TABLE roles (
    id   SMALLSERIAL PRIMARY KEY,
    name VARCHAR(20) NOT NULL UNIQUE CHECK (name IN ('admin', 'staff', 'customer'))
);

CREATE TABLE users (
    id            SERIAL PRIMARY KEY,
    role_id       SMALLINT     NOT NULL REFERENCES roles(id),
    email         VARCHAR(255) NOT NULL UNIQUE,
    password_hash TEXT         NOT NULL,
    full_name     VARCHAR(120) NOT NULL,
    is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT now()
);

-- ===================== Accounts =====================
CREATE TABLE institutions (
    id        SERIAL PRIMARY KEY,
    name      VARCHAR(120) NOT NULL UNIQUE,
    is_active BOOLEAN     NOT NULL DEFAULT TRUE
);

CREATE TABLE account_types (
    id            SMALLSERIAL PRIMARY KEY,
    name          VARCHAR(40) NOT NULL UNIQUE,
    is_investment BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE TABLE accounts (
    id              SERIAL PRIMARY KEY,
    user_id         INT           NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    institution_id  INT           NOT NULL REFERENCES institutions(id),
    account_type_id SMALLINT      NOT NULL REFERENCES account_types(id),
    name            VARCHAR(80)   NOT NULL,
    last4           CHAR(4)       CHECK (last4 ~ '^[0-9]{4}$'),
    opening_balance NUMERIC(14,2) NOT NULL DEFAULT 0,
    is_active       BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ   NOT NULL DEFAULT now()
);
-- Names may be reused across institutions and account types, while staying unique
-- within one institution and account type for each user.
CREATE UNIQUE INDEX uq_accounts_user_institution_type_name
    ON accounts (user_id, institution_id, account_type_id, name);

-- ===================== Categories & classification rules =====================
-- user_id NULL = system category visible to everyone; otherwise private to that user.
CREATE TABLE categories (
    id      SERIAL PRIMARY KEY,
    user_id INT         REFERENCES users(id) ON DELETE CASCADE,
    name    VARCHAR(60) NOT NULL,
    kind    VARCHAR(10) NOT NULL CHECK (kind IN ('income', 'expense', 'transfer'))
);
CREATE UNIQUE INDEX uq_categories_owner_name ON categories (COALESCE(user_id, 0), lower(name));

-- Keyword rules are the cheap, deterministic first pass before the AI is asked.
CREATE TABLE category_rules (
    id          SERIAL PRIMARY KEY,
    user_id     INT          REFERENCES users(id) ON DELETE CASCADE,   -- NULL = system rule
    keyword     VARCHAR(60)  NOT NULL,
    category_id INT          NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX uq_rules_owner_keyword ON category_rules (COALESCE(user_id, 0), lower(keyword));

-- ===================== Transactions =====================
-- amount is signed: negative = money out, positive = money in.
CREATE TABLE transactions (
    id              BIGSERIAL PRIMARY KEY,
    account_id      INT           NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    category_id     INT           NOT NULL REFERENCES categories(id),
    txn_date        DATE          NOT NULL,
    description     VARCHAR(255)  NOT NULL,
    amount          NUMERIC(14,2) NOT NULL CHECK (amount <> 0),
    category_source VARCHAR(10)   NOT NULL DEFAULT 'manual'
                    CHECK (category_source IN ('manual', 'rule', 'ai', 'default')),
    ai_confidence   NUMERIC(3,2)  CHECK (ai_confidence BETWEEN 0 AND 1),
    created_at      TIMESTAMPTZ   NOT NULL DEFAULT now()
);
CREATE INDEX ix_txn_account_date ON transactions (account_id, txn_date DESC);
CREATE INDEX ix_txn_category     ON transactions (category_id);

-- ===================== Budgets & goals =====================
CREATE TABLE budgets (
    id           SERIAL PRIMARY KEY,
    user_id      INT           NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    category_id  INT           NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    budget_month DATE          NOT NULL CHECK (EXTRACT(DAY FROM budget_month) = 1),
    limit_amount NUMERIC(12,2) NOT NULL CHECK (limit_amount > 0),
    UNIQUE (user_id, category_id, budget_month)
);

CREATE TABLE goals (
    id            SERIAL PRIMARY KEY,
    user_id       INT           NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    account_id    INT           REFERENCES accounts(id) ON DELETE SET NULL,
    name          VARCHAR(100)  NOT NULL,
    target_amount NUMERIC(12,2) NOT NULL CHECK (target_amount > 0),
    target_date   DATE,
    status        VARCHAR(10)   NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'achieved', 'abandoned')),
    created_at    TIMESTAMPTZ   NOT NULL DEFAULT now(),
    UNIQUE (user_id, name)
);

CREATE TABLE goal_contributions (
    id             SERIAL PRIMARY KEY,
    goal_id        INT           NOT NULL REFERENCES goals(id) ON DELETE CASCADE,
    amount         NUMERIC(12,2) NOT NULL CHECK (amount > 0),
    contributed_on DATE          NOT NULL DEFAULT CURRENT_DATE,
    note           VARCHAR(200)
);
CREATE INDEX ix_contrib_goal ON goal_contributions (goal_id);

-- ===================== Investment portfolio =====================
CREATE TABLE asset_classes (
    id   SMALLSERIAL PRIMARY KEY,
    name VARCHAR(40) NOT NULL UNIQUE
);

CREATE TABLE securities (
    id             SERIAL PRIMARY KEY,
    symbol         VARCHAR(12) NOT NULL UNIQUE,
    name           VARCHAR(120) NOT NULL,
    asset_class_id SMALLINT    NOT NULL REFERENCES asset_classes(id)
);

CREATE TABLE security_prices (
    security_id INT           NOT NULL REFERENCES securities(id) ON DELETE CASCADE,
    price_date  DATE          NOT NULL,
    close_price NUMERIC(14,4) NOT NULL CHECK (close_price > 0),
    PRIMARY KEY (security_id, price_date)
);

CREATE TABLE investment_trades (
    id          SERIAL PRIMARY KEY,
    account_id  INT           NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    security_id INT           NOT NULL REFERENCES securities(id),
    trade_type  VARCHAR(4)    NOT NULL CHECK (trade_type IN ('buy', 'sell')),
    quantity    NUMERIC(18,6) NOT NULL CHECK (quantity > 0),
    price       NUMERIC(14,4) NOT NULL CHECK (price > 0),
    fee         NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (fee >= 0),
    trade_date  DATE          NOT NULL DEFAULT CURRENT_DATE
);
CREATE INDEX ix_trades_account_security ON investment_trades (account_id, security_id);

-- ===================== System tables =====================
CREATE TABLE audit_log (
    id         BIGSERIAL PRIMARY KEY,
    table_name VARCHAR(40) NOT NULL,
    record_id  INT         NOT NULL,
    action     VARCHAR(10) NOT NULL,
    old_data   JSONB,
    new_data   JSONB,
    changed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Saved generated insight summaries (one row per generation).
CREATE TABLE ai_insights (
    id           SERIAL PRIMARY KEY,
    user_id      INT         NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    period_month DATE        NOT NULL,
    content      JSONB       NOT NULL,
    model        VARCHAR(60) NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_insights_user ON ai_insights (user_id, created_at DESC);
