-- Example queries for the project report. Replace :uid with a user id (e.g. the demo user's id).
-- (This folder is NOT run by docker-entrypoint-initdb.d; run them manually in psql / pgAdmin.)

-- 1) Multi-table JOIN + aggregate: spending by category and institution, this month
SELECT c.name AS category, i.name AS institution, COUNT(*) AS txns, -SUM(t.amount) AS spent
FROM transactions t
JOIN accounts   a ON a.id = t.account_id
JOIN institutions i ON i.id = a.institution_id
JOIN categories c ON c.id = t.category_id
WHERE a.user_id = :uid AND c.kind = 'expense'
  AND t.txn_date >= date_trunc('month', current_date)
GROUP BY c.name, i.name
ORDER BY spent DESC;

-- 2) Subquery: categories where this month's spend is already above the user's 3-month average
SELECT cur.category, cur.total AS this_month,
       (SELECT ROUND(AVG(h.total), 2) FROM v_monthly_category_spend h
         WHERE h.user_id = cur.user_id AND h.category_id = cur.category_id
           AND h.month >= date_trunc('month', current_date) - INTERVAL '3 months'
           AND h.month <  date_trunc('month', current_date)) AS avg_prev_3_months
FROM v_monthly_category_spend cur
WHERE cur.user_id = :uid AND cur.kind = 'expense'
  AND cur.month = date_trunc('month', current_date)::date
  AND cur.total > (SELECT AVG(h.total) FROM v_monthly_category_spend h
                    WHERE h.user_id = cur.user_id AND h.category_id = cur.category_id
                      AND h.month >= date_trunc('month', current_date) - INTERVAL '3 months'
                      AND h.month <  date_trunc('month', current_date));

-- 3) HAVING: budgets that are already over 80% used
SELECT category, budget_month, limit_amount, spent, pct_used
FROM v_budget_status
WHERE user_id = :uid AND pct_used >= 80
ORDER BY pct_used DESC;

-- 4) NOT EXISTS: customers who have not set any budget yet
SELECT u.id, u.full_name
FROM users u JOIN roles r ON r.id = u.role_id AND r.name = 'customer'
WHERE NOT EXISTS (SELECT 1 FROM budgets b WHERE b.user_id = u.id);

-- 5) Window function: running balance for one account
SELECT t.txn_date, t.description, t.amount,
       a.opening_balance + SUM(t.amount) OVER (ORDER BY t.txn_date, t.id) AS running_balance
FROM transactions t JOIN accounts a ON a.id = t.account_id
WHERE a.id = :account_id
ORDER BY t.txn_date, t.id;

-- 6) How well is the AI doing? Share of transactions by classification source
SELECT category_source, COUNT(*) AS txns,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct,
       ROUND(AVG(ai_confidence), 2) AS avg_confidence
FROM transactions
GROUP BY category_source;

-- 7) Calling a stored procedure / reading a view
CALL sp_copy_budgets(:uid, date_trunc('month', current_date)::date,
                     (date_trunc('month', current_date) + INTERVAL '1 month')::date, 0);
SELECT * FROM v_net_worth WHERE user_id = :uid;
