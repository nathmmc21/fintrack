-- Add selectable crypto assets for the Portfolio tracker.
-- Prices are entered by the user; this does not connect to an exchange or provide quotes.
BEGIN;

INSERT INTO asset_classes (name)
VALUES ('Crypto')
ON CONFLICT (name) DO NOTHING;

INSERT INTO securities (symbol, name, asset_class_id)
SELECT v.symbol, v.name, ac.id
FROM (VALUES
    ('BTC', 'Bitcoin'),
    ('ETH', 'Ethereum'),
    ('SOL', 'Solana'),
    ('XRP', 'XRP')
) AS v(symbol, name)
JOIN asset_classes ac ON ac.name = 'Crypto'
ON CONFLICT (symbol) DO NOTHING;

COMMIT;
